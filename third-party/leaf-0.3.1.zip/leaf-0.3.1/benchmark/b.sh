ninja
rm benchmark.csv
./deep_stack_leaf
./deep_stack_tl
./deep_stack_result
./deep_stack_outcome
