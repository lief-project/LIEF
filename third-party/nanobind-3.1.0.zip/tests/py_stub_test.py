"""Example module docstring."""
import sys

if sys.version_info < (3, 11, 0):
    # Work around limitations in typing.overload in Python<3.11
    import typing_extensions as typing
else:
    import typing

# Ignore a type and a function from elsewhere. These shouldn't be included in
# the stub by default
from os import PathLike, getcwd

del sys

C = 123
T = typing.TypeVar("T")


class ArrayLike:
    # Mimics a NumPy array: comparisons return an object whose truth value is
    # ambiguous. This used to crash the stub generator's cycle check (#1335).
    def __eq__(self, other):
        return self

    def __bool__(self):
        raise ValueError("ambiguous truth value")


ARRAY_LIKE = ArrayLike()

def f1(a, b, c, /):
    """docstring"""

def f2(a=(3,(4,5)), /, b=(1,2), *, c=4):
    """docstring 2"""

def f3(*args, **kwargs):
    pass

def f4() -> typing.Callable[[T], T]:
    return lambda x: x

class AClass:
    STATIC_VAR: int = 5

    class NestedClass:
        pass

    def __init__(self, x):
        pass

    def method(self, x: str):
        pass

    @staticmethod
    def static_method(x):
        pass

    @classmethod
    def class_method(cls, x):
        pass

    @typing.overload
    def overloaded(self, x: int) -> None:
        """docstr 1"""

    @typing.overload
    def overloaded(self, x: str) -> None:
        """docstr 2"""

    def overloaded(self, x):
        pass

    @typing.overload
    def overloaded_2(self, x: int) -> None: ...

    @typing.overload
    def overloaded_2(self, x: str) -> None: ...

    def overloaded_2(self, x):
        "docstr 3"

    def _set_write_only(self, value: int) -> None:
        pass

    def _set_write_only_untyped(self, value):
        pass

    # Write-only properties are emitted as plain attributes with the setter's
    # value type (or typing.Any if unannotated)
    write_only = property(fset=_set_write_only)
    write_only_untyped = property(fset=_set_write_only_untyped)


class Sentinel:
    pass


# A class attribute holding an instance of the enclosing class. Stubgen used
# to render it as an enum member and crash.
Sentinel.INSTANCE = Sentinel()


class SigMember:
    # A member type that dictates the stub declaration of the member holding
    # it, which stubgen emits in place of the usual 'name: type = value'
    __nb_signature__ = "MODULE_MEMBER: tuple[int, ...]"


MODULE_MEMBER = SigMember()


class LazySigMember:
    # The declaration may also be computed on demand, and span several lines
    @property
    def __nb_signature__(self):
        return "# a comment\n_private: dict[str, int]\n"


class Holder:
    # Providing a declaration opts an otherwise private name into the stub
    _private = LazySigMember()
