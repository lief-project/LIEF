import test_enum_ext as t
import enum
import pytest

def test01_unsigned_enum():
    assert repr(t.Enum.A) == 'Enum.A'
    assert str(t.Enum.A) == 'Enum.A'
    assert repr(t.Enum.B) == 'Enum.B'
    assert str(t.Enum.B) == 'Enum.B'
    assert repr(t.Enum.C) == 'Enum.C'
    assert str(t.Enum.C) == 'Enum.C'
    assert t.Enum.A.name == 'A'
    assert t.Enum.B.name == 'B'
    assert t.Enum.C.name == 'C'
    assert t.Enum.A.__name__ == 'A'
    assert t.Enum.B.__name__ == 'B'
    assert t.Enum.C.__name__ == 'C'

    assert t.Enum.__doc__ == 'enum-level docstring'

    assert t.Enum.A.__doc__ == 'Value A'
    assert t.Enum.B.__doc__ == 'Value B'
    assert t.Enum.C.__doc__ == 'Value C'
    assert t.Enum.A.value == 0
    assert t.Enum.B.value == 1
    assert t.Enum.C.value == 0xffffffff
    assert t.Enum(0) is t.Enum.A
    assert t.Enum(1) is t.Enum.B
    assert t.Enum(0xffffffff) is t.Enum.C
    assert t.Enum(t.Enum.A) is t.Enum.A
    assert t.Enum(t.Enum.B) is t.Enum.B
    assert t.Enum(t.Enum.C) == t.Enum.C
    assert t.from_enum(t.Enum.A) == 0
    assert t.from_enum(t.Enum.B) == 1
    assert t.from_enum(t.Enum.C) == 0xffffffff
    assert t.to_enum(0).__name__ == 'A'
    assert t.to_enum(0) == t.Enum.A
    assert t.to_enum(1) == t.Enum.B
    assert t.to_enum(0xffffffff) == t.Enum.C

    with pytest.raises(ValueError) as excinfo:
        t.to_enum(5)
    assert '5 is not a valid Enum' in str(excinfo.value)

    with pytest.raises(ValueError) as excinfo:
        t.Enum(123)
    assert '123 is not a valid Enum' in str(excinfo.value)

    assert t.from_enum_implicit(0) == 0

    with pytest.raises(TypeError):
        t.from_enum_implicit(123)


def test02_signed_enum():
    assert repr(t.SEnum.A) == 'SEnum.A'
    assert repr(t.SEnum.B) == 'SEnum.B'
    assert repr(t.SEnum.C) == 'SEnum.C'
    assert str(t.SEnum.A) == 'SEnum.A'
    assert str(t.SEnum.B) == 'SEnum.B'
    assert str(t.SEnum.C) == 'SEnum.C'
    assert int(t.SEnum.A) == 0
    assert int(t.SEnum.B) == 1
    assert int(t.SEnum.C) == -1
    assert t.SEnum.A.value == 0
    assert t.SEnum.B.value == 1
    assert t.SEnum.C.value == -1
    assert t.SEnum(0) is t.SEnum.A
    assert t.SEnum(1) is t.SEnum.B
    assert t.SEnum(-1) is t.SEnum.C
    assert t.from_enum(t.SEnum.A) == 0
    assert t.from_enum(t.SEnum.B) == 1
    assert t.from_enum(t.SEnum.C) == -1

    # Arithmetic enums derive from 'enum.IntEnum' and must convert
    # to a plain integer argument
    assert t.to_enum(t.SEnum.B) is t.Enum.B


def test14_enum_alias():
    assert t.Enum.BAlias is t.Enum.B
    assert t.Enum.BAlias.name == "B"
    assert list(t.Enum) == [t.Enum.A, t.Enum.B, t.Enum.C]


def test03_enum_arithmetic():
    assert t.SEnum.B + 2 == 3
    assert t.SEnum.B + 2.5 == 3.5
    assert 2 + t.SEnum.B == 3
    assert 2.5 + t.SEnum.B == 3.5
    assert t.SEnum.B >> t.SEnum.B == 0
    assert t.SEnum.B << t.SEnum.B == 2
    assert -t.SEnum.B == -1 and -t.SEnum.C == 1
    assert t.SEnum.B & t.SEnum.B == 1
    assert t.SEnum.B & ~t.SEnum.B == 0

    with pytest.raises(TypeError, match="unsupported operand type"):
        t.Enum.B + 2
    with pytest.raises(TypeError, match="unsupported operand type"):
        t.SEnum.B - "1"
    with pytest.raises(TypeError, match="unsupported operand type"):
        t.SEnum.B >> 1.0


def test04_enum_export():
    assert t.Item1 is t.ClassicEnum.Item1 and t.Item1.value == 0
    assert t.Item2 is t.ClassicEnum.Item2 and t.Item2.value == 1

# test for issue #39
def test05_enum_property():
    w = t.EnumProperty()
    assert w.read_enum == t.Enum.A
    assert str(w.read_enum) == 'Enum.A'

def test08_enum_comparisons():
    assert int(t.SEnum.B) == 1
    for enum in (t.SEnum,):
        value = getattr(enum, "B")
        assert value != str(int(value))
        assert value != int(value) + 0.4
        assert value < int(value) + 0.4
        for i in (0, 0.5, 1, 1.5, 2):
            assert (value == i) == (int(value) == i)
            assert (value != i) == (int(value) != i)
            assert (value < i) == (int(value) < i)
            assert (value <= i) == (int(value) <= i)
            assert (value >= i) == (int(value) >= i)
            assert (value > i) == (int(value) > i)

            assert (i == value) == (i == int(value))
            assert (i != value) == (i != int(value))
            assert (i < value) == (i < int(value))
            assert (i <= value) == (i <= int(value))
            assert (i >= value) == (i >= int(value))
            assert (i > value) == (i > int(value))

        for unrelated in (None, "hello", "1"):
            assert value != unrelated and unrelated != value
            assert not (value == unrelated) and not (unrelated == value)
            with pytest.raises(TypeError):
                value < unrelated
            with pytest.raises(TypeError):
                unrelated < value

    # different enum types never compare equal ...
    assert t.Enum.B != t.SEnum.B and t.SEnum.B != t.Enum.B
    assert not (t.Enum.B == t.SEnum.B) and not (t.SEnum.B == t.Enum.B)
    assert t.Enum.B != t.SEnum.C and t.SEnum.C != t.Enum.B

def test06_enum_flag():
    # repr / str tests
    assert repr(t.Flag.A) == 'Flag.A'
    assert str(t.Flag.A) == 'Flag.A'
    assert repr(t.Flag.B) == 'Flag.B'
    assert str(t.Flag.B) == 'Flag.B'
    assert repr(t.Flag.C) == 'Flag.C'
    assert str(t.Flag.C) == 'Flag.C'
    assert repr(t.Flag.A | t.Flag.B) in ['Flag.A|B', 'Flag.B|A']
    assert str(t.Flag.A | t.Flag.B) in ['Flag.A|B', 'Flag.B|A']
    assert repr(t.Flag.A | t.Flag.B | t.Flag.C) in ['Flag.A|B|C', 'Flag.C|B|A']
    assert str(t.Flag.A | t.Flag.B | t.Flag.C) in ['Flag.A|B|C', 'Flag.C|B|A']

    # Flag membership tests
    assert (t.Flag(1) | t.Flag(2)).value == 3
    assert (t.Flag(3) & t.Flag(1)).value == 1
    assert (t.Flag(3) ^ t.Flag(1)).value == 2
    assert (t.Flag(3) ==  (t.Flag.A | t.Flag.B))

    # ensure the flag mask is set correctly by enum_append in Python 3.11+
    if hasattr(t.Flag, "_flag_mask_"):
        assert t.Flag._flag_mask_ == 7
    assert (t.from_enum(t.Flag.A | t.Flag.C) == 5)
    assert (t.from_enum_implicit(t.Flag(1) | t.Flag(4)) == 5)

    # unsigned flag tests to verify correct type casting behavior
    # (in particular, overflow protection in enum_from_python.)
    assert (t.UnsignedFlag(1) | t.UnsignedFlag(2)).value == 3
    assert t.UnsignedFlag.A.value == 1
    assert t.UnsignedFlag.B.value == 2
    assert t.UnsignedFlag.All.value == 0xffffffffffffffff
    assert t.UnsignedFlag(t.UnsignedFlag.A) is t.UnsignedFlag.A
    assert t.UnsignedFlag(t.UnsignedFlag.B) is t.UnsignedFlag.B
    assert t.UnsignedFlag(t.UnsignedFlag.All) is t.UnsignedFlag.All
    assert t.from_enum(t.UnsignedFlag.A) == 1
    assert t.from_enum(t.UnsignedFlag.B) == 2
    assert t.from_enum(t.UnsignedFlag.All) == 0xffffffffffffffff

    assert t.to_flag(1) == t.Flag.A
    assert t.to_flag(2) == t.Flag.B
    assert t.to_flag(4) == t.Flag.C
    assert t.to_flag(5) == (t.Flag.A | t.Flag.C)

    # Returning a flag value with bits outside the registered mask must raise
    # a catchable Python exception rather than aborting the process. Python
    # 3.11.0-3.11.3 use a CONFORM boundary by default, which drops such bits.
    if hasattr(enum, 'CONFORM') and t.Flag._boundary_ is enum.CONFORM:
        assert t.to_flag(8) == t.Flag(0)
    else:
        with pytest.raises(ValueError):
            t.to_flag(8)

def test09_enum_methods():
    assert t.Item1.my_value == 0 and t.Item2.my_value == 1
    assert t.Item1.get_value() == 0 and t.Item2.get_value() == 1
    assert t.Item1.foo() == t.Item1
    assert t.ClassicEnum.bar(t.Item1) == t.Item1

def test10_enum_opaque():
    assert t.OpaqueEnum.X == t.OpaqueEnum("X") and t.OpaqueEnum.Y == t.OpaqueEnum("Y")

def test12_str_enum():
    assert isinstance(t.Color.Red, str)
    assert isinstance(t.Color.Red, t.Color)
    assert t.Color.Red == "red"
    assert t.Color.Green == "green"
    assert t.Color.Blue == "blue"

    assert t.Color.Red.name == "Red"
    assert t.Color.Red._name_ == "Red"
    assert t.Color.Red.value == "red"
    assert t.Color.Red._value_ == "red"

    assert t.Color.__doc__ == "string-valued enum"
    assert t.Color.Red.__doc__ is None

    assert str(t.Color.Red) == "Color.Red"
    assert repr(t.Color.Red) == "Color.Red"
    assert str(t.Color.Green) == "Color.Green"
    assert repr(t.Color.Green) == "Color.Green"

    assert t.Color("red") is t.Color.Red
    assert t.Color("green") is t.Color.Green
    assert t.Color(t.Color.Blue) is t.Color.Blue

    with pytest.raises(ValueError):
        t.Color("not-a-color")

    assert t.from_color(t.Color.Red) == 0
    assert t.from_color(t.Color.Green) == 1
    assert t.from_color(t.Color.Blue) == 2
    assert t.to_color(0) is t.Color.Red
    assert t.to_color(1) is t.Color.Green
    assert t.to_color(2) is t.Color.Blue

    with pytest.raises(ValueError) as excinfo:
        t.to_color(99)
    assert '99 is not a valid Color' in str(excinfo.value)

    # convert: bare strings are accepted.
    assert t.from_color_implicit("red") == 0
    assert t.from_color_implicit("green") == 1
    assert t.from_color_implicit("blue") == 2
    assert t.from_color_implicit(t.Color.Red) == 0

    with pytest.raises(TypeError):
        t.from_color_implicit("not-a-color")

    # convert: StrEnum is keyed by string value, not the underlying C++ integer.
    with pytest.raises(TypeError):
        t.from_color_implicit(0)

    # noconvert: a bare string is not accepted, even if it would match.
    with pytest.raises(TypeError):
        t.from_color("red")


def test11_enum_name_value_members():
    # Test for issue #1246: enums with members named 'name' or 'value'
    # When an enum has members named 'name' or 'value', accessing .name/.value
    # returns the enum member instead of the attribute. Use _name_/_value_.
    assert t.Item.name._value_ == 0
    assert t.Item.value._value_ == 1
    assert t.Item.extra._value_ == 2
    assert t.Item.name._name_ == 'name'
    assert t.Item.value._name_ == 'value'
    assert t.Item.extra._name_ == 'extra'
    assert t.item_to_int(t.Item.name) == 0
    assert t.item_to_int(t.Item.value) == 1
    assert t.item_to_int(t.Item.extra) == 2
    assert t.item_to_int() == 0  # default is Item.name


def test13_no_implicit_self_conversion():
    # 'EnumWrapper' is implicitly constructible from 'EnumWrapper.Value'. That
    # conversion must not apply to the implicit 'self' argument of an unbound
    # method call, since the method would then run on a temporary.
    w = t.EnumWrapper(t.EnumWrapper.Value.Beta)
    assert w.get_value() == t.EnumWrapper.Value.Beta
    assert t.EnumWrapper.get_value(w) == t.EnumWrapper.Value.Beta

    with pytest.raises(TypeError):
        t.EnumWrapper.get_value(t.EnumWrapper.Value.Beta)
