import sys
from itertools import permutations
import test_classes_ext as t
import pytest
from common import is_pypy, skip_on_pypy, collect, parallelize



def optional(arg: str, /) -> str:
    return arg + " | " + "None"


@pytest.fixture
def clean():
    collect()
    t.reset()


def assert_stats(**kwargs):
    collect()
    for k, v in t.stats().items():
        fail = False
        if k in kwargs:
            if v != kwargs[k]:
                fail = True
        elif v != 0:
            fail = True
        if fail:
            raise Exception(f"Mismatch for key {k}: {t.stats()}")


def test01_signature():
    assert t.Struct.__init__.__doc__ == (
        "__init__(self) -> None\n" "__init__(self, arg: int, /) -> None"
    )

    assert t.Struct.value.__doc__ == "value(self) -> int"
    assert t.Struct.create_move.__doc__ == "create_move() -> test_classes_ext.Struct"
    assert t.Struct.set_value.__doc__ == "set_value(self, value: int) -> None"
    assert t.Struct().set_value.__doc__ == "set_value(self, value: int) -> None"
    assert t.Struct.__doc__ == "Some documentation"
    assert t.Struct.static_test.__doc__ == (
        "static_test(arg: int, /) -> int\n" "static_test(arg: float, /) -> int"
    )


def test02_static_overload():
    assert t.Struct.static_test(1) == 1
    assert t.Struct.static_test(1.0) == 2


def test03_instantiate(clean):
    s1: t.Struct = t.Struct()
    assert s1.value() == 5
    assert s1.value_plus(1, 2, 3, 4, 5, 6, 7) == 33
    s2 = t.Struct(10)
    assert s2.value() == 10
    del s1
    del s2
    assert_stats(default_constructed=1, value_constructed=1, destructed=2)


def test04_double_init():
    s = t.Struct()
    with pytest.warns(
        RuntimeWarning,
        match="nanobind: attempted to initialize an already-initialized instance of type",
    ):
        with pytest.raises(TypeError):
            s.__init__(3)


def test05_rv_policy(clean):
    s = t.Struct()
    assert s.self() is s
    assert s.none() is None
    del s
    assert_stats(default_constructed=1, destructed=1)

    # ------

    t.reset()
    assert t.Struct.create_take().value() == 10
    assert_stats(value_constructed=1, destructed=1)

    # ------

    t.reset()
    assert t.Struct.create_move().value() == 11
    assert_stats(value_constructed=1, move_constructed=1, destructed=2)

    # ------

    t.reset()
    assert t.Struct.create_reference().value() == 12
    assert_stats()

    # ------

    t.reset()
    assert t.Struct.create_copy().value() == 12
    assert_stats(copy_constructed=1, destructed=1)


def test06_reference_internal(clean):
    s = t.PairStruct()
    s1 = s.s1
    s2 = s.s2
    del s
    assert_stats(default_constructed=2)
    assert s2.value() == 5
    del s2

    assert_stats(default_constructed=2)

    assert s1.value() == 5
    del s1
    assert_stats(default_constructed=2, destructed=2)

    # ----

    s = t.PairStruct()
    s1 = s.s1
    del s1
    del s


def test06c_init_not_list_initialization():
    # Issue #1074: nb::init must use direct- rather than list-initialization, so
    # that a std::initializer_list constructor is not spuriously preferred.
    assert t.InitListTest(1).value == 1


def test06b_reference_internal_free(clean):
    # A free function with reference_internal has no 'self' to keep-alive the
    # result on. It must fail consistently regardless of arity (the 1-arg case
    # is dispatched via the 'simple_1' vectorcall path, which previously
    # mistakenly used its sole argument as the cleanup 'self').
    with pytest.raises(TypeError):
        t.create_reference_internal_free()
    with pytest.raises(TypeError):
        t.create_reference_internal_free_1arg(0)


def test07_big():
    x = [t.Big() for i in range(1024)]
    x2 = [t.BigAligned() for i in range(1024)]


def test08_inheritance():
    dog = t.Dog("woof")
    cat = t.Cat("meow")
    assert dog.name() == "Dog"
    assert cat.name() == "Cat"
    assert dog.what() == "woof"
    assert cat.what() == "meow"
    assert isinstance(dog, t.Animal) and isinstance(dog, t.Dog)
    assert isinstance(cat, t.Animal) and isinstance(cat, t.Cat)
    assert t.go(dog) == "Dog says woof"
    assert t.go(cat) == "Cat says meow"

    assert t.animal_passthrough(dog) is dog
    assert t.animal_passthrough(cat) is cat
    assert t.dog_passthrough(dog) is dog

    with pytest.raises(TypeError):
        t.dog_passthrough(cat)


def test09_method_vectorcall():
    out = []

    def f(a, b, c, d, e):
        out.append((a, b, c, d, e))

    class MyClass:
        def f(self, a, b, c, d, e):
            self.out = (a, b, c, d, e)

    t.call_function(f)

    i = MyClass()
    t.call_method(i)
    assert out == [(1, 2, "hello", True, 4)]
    assert i.out == (1, 2, "hello", True, 4)


def test10_trampoline(clean):
    for _ in range(10):

        class Dachshund(t.Animal):
            def __init__(self):
                super().__init__()

            def name(self):
                return "Dachshund"

            def what(self):
                return "yap"

        d = Dachshund()
        for _ in range(10):
            assert t.go(d) == "Dachshund says yap"

        assert t.animal_passthrough(d) is d

    a = 0

    class GenericAnimal(t.Animal):
        def what(self):
            return "goo"

        def void_ret(self):
            nonlocal a
            a += 1

        def name(self):
            return "Generic" + super().name()

    ga = GenericAnimal()
    assert t.go(ga) == "GenericAnimal says goo"
    assert t.void_ret(ga) is None
    assert a == 1
    assert t.animal_passthrough(ga) is ga

    del ga
    del d

    assert_stats(default_constructed=11, destructed=11)

    class GenericDog(t.Dog):
        pass

    d = GenericDog("GenericDog")
    assert t.dog_passthrough(d) is d
    assert t.animal_passthrough(d) is d


def test11_trampoline_failures():
    class Incomplete(t.Animal):
        def __init__(self):
            super().__init__()

        def void_ret(self):
            raise TypeError("propagating an exception")

    d = Incomplete()
    with pytest.raises(RuntimeError) as excinfo:
        t.go(d)
    assert (
        "test_classes.Incomplete::what()'): tried to call a pure virtual function!"
        in str(excinfo.value)
    )

    with pytest.raises(TypeError) as excinfo:
        t.void_ret(d)
    assert "propagating an exception" in str(excinfo.value)

    class Incomplete2(t.Animal):
        def __init__(self):
            pass  # Missing call to super().__init__()

        def name(self):
            return "a"

        def what(self):
            return "b"

    with pytest.warns(
        RuntimeWarning,
        match="nanobind: attempted to access an uninitialized instance of type",
    ):
        with pytest.raises(TypeError) as excinfo:
            t.go(Incomplete2())
    assert "incompatible function arguments" in str(excinfo.value)


def test12_large_pointers():
    import struct

    for i in range(1, 10):
        c = t.i2p(i)
        assert isinstance(c, t.Foo)
        assert t.p2i(c) == i

    large = (1 << (struct.calcsize("P") * 8)) - 1
    for i in range(large - 10, large):
        c = t.i2p(i)
        assert isinstance(c, t.Foo)
        assert t.p2i(c) == i


def test13_implicitly_convertible():
    assert t.get_d.__doc__ == "get_d(arg: test_classes_ext.D, /) -> int"
    a = t.A(1)
    b = t.B(2)
    b2 = t.B2(3)
    c = t.C(4)
    i = 5

    with pytest.raises(TypeError) as excinfo:
        t.get_d(c)
    assert str(excinfo.value) == (
        "get_d(): incompatible function arguments. The following argument types are supported:\n"
        "    1. get_d(arg: test_classes_ext.D, /) -> int\n"
        "\n"
        "Invoked with types: test_classes_ext.C"
    )
    with pytest.raises(TypeError):
        t.get_optional_d(c)

    for obj, expected in ((a, 11), (b, 102), (b2, 103), (i, 10005)):
        assert t.get_d(obj) == expected
        assert t.get_optional_d(obj) == expected
        # The -1's here are because nb::cast() won't implicit-convert to a
        # pointer because it would dangle
        assert t.get_d_via_cast(obj) == (expected, -1, expected, -1)
        assert t.get_d_via_try_cast(obj) == (expected, -1, expected, -1)

    d = t.D(5)
    assert t.get_d(d) == 10005
    assert t.get_optional_d(d) == 10005

    # The copy constructor must copy without invoking an implicit conversion
    # (D(D(...)) would otherwise recurse), and implicit conversions of other
    # argument types must still work in its presence
    d2 = t.D(d)
    assert d2.value == 10005
    assert t.D(a).value == 11
    assert t.get_d_via_cast(d) == (10005, 10005, 10005, 10005)
    assert t.get_d_via_try_cast(d) == (10005, 10005, 10005, 10005)

    assert t.get_optional_d(None) == -1
    assert t.get_d_via_cast(c) == (-1, -1, -1, -1)
    assert t.get_d_via_try_cast(c) == (-1, -1, -1, -1)


def test14_operators():
    a = t.Int(1)
    b = t.Int(2)
    assert repr(a + b) == "3"
    with pytest.raises(TypeError) as excinfo:
        assert repr(a - b) == "3"
    assert "unsupported operand type" in str(excinfo.value)
    assert repr(a - 2) == "-1"
    a_before = id(a)
    a += b
    assert id(a) == a_before
    assert repr(a) == "3"
    assert repr(b) == "2"

    assert a.__add__("test") is NotImplemented


def test15_keep_alive_nbtype(clean):
    t.reset()
    s = t.Struct()
    a = t.Dog("Rufus")
    assert t.keep_alive_arg(s, a) is a
    assert t.keep_alive_arg(s, a) is a
    del s
    assert_stats(default_constructed=1)
    del a
    assert_stats(default_constructed=1, destructed=1)

    t.reset()
    s = t.Struct()
    a = t.Dog("Rufus")
    assert t.keep_alive_ret(a, s) is s
    assert t.keep_alive_ret(a, s) is s
    del a
    assert_stats(default_constructed=1)
    del s
    assert_stats(default_constructed=1, destructed=1)


def test16_keep_alive_custom(clean):
    constructed = 0
    destructed = 0

    class Struct:
        def __init__(self):
            nonlocal constructed
            constructed += 1

        def __del__(self):
            nonlocal destructed
            destructed += 1

    class Struct2:
        def __init__(self):
            pass

    s = Struct()
    a = Struct2()
    assert t.keep_alive_arg(s, a) is a
    del s
    collect()
    assert constructed == 1 and destructed == 0
    del a
    collect()
    assert constructed == 1 and destructed == 1

    s = Struct()
    a = Struct2()
    assert t.keep_alive_ret(a, s) is s
    del a
    collect()
    assert constructed == 2 and destructed == 1
    del s
    collect()
    assert constructed == 2 and destructed == 2

    with pytest.raises(RuntimeError) as excinfo:
        s = Struct()
        x = 5
        t.keep_alive_ret(x, s)

    assert "nanobind::detail::keep_alive_py(): could not create a weak reference!" in str(
        excinfo.value
    )


def test16b_inst_python_derived():
    class Dachshund(t.Dog):
        pass

    assert not t.inst_python_derived(t.Dog("Rufus"))
    assert t.inst_python_derived(Dachshund("Rufus"))
    assert not t.inst_python_derived(t.Struct())


def test16c_keep_alive_functions(clean):
    # nb::keep_alive_obj() with a nanobind nurse
    t.reset()
    nurse = t.Dog("Rufus")
    patient = t.Struct()
    t.keep_alive_obj(nurse, patient)
    t.keep_alive_obj(nurse, patient)  # repeated registration is a no-op
    del patient
    assert_stats(default_constructed=1)
    del nurse
    assert_stats(default_constructed=1, destructed=1)

    # .. and with an arbitrary weak-referenceable nurse
    t.reset()

    class Nurse:
        pass

    nurse = Nurse()
    patient = t.Struct()
    t.keep_alive_obj(nurse, patient)
    del patient
    assert_stats(default_constructed=1)
    del nurse
    collect()
    assert_stats(default_constructed=1, destructed=1)

    # None as nurse or patient does nothing
    t.keep_alive_obj(None, t.Struct())
    t.keep_alive_obj(t.Struct(), None)

    with pytest.raises(RuntimeError, match="could not create a weak reference"):
        t.keep_alive_obj(5, t.Struct())

    # nb::keep_alive_cb() releases the payload when the nurse expires
    base = t.keep_alive_cb_deleted()
    nurse = t.Dog("Rufus")
    t.keep_alive_cb(nurse)
    t.keep_alive_cb(nurse)
    assert t.keep_alive_cb_deleted() == base
    del nurse
    collect()
    assert t.keep_alive_cb_deleted() == base + 2

    nurse = Nurse()
    t.keep_alive_cb(nurse)
    assert t.keep_alive_cb_deleted() == base + 2
    del nurse
    collect()
    assert t.keep_alive_cb_deleted() == base + 3


def f():
    pass


class MyClass:
    def f(self):
        pass

    class NestedClass:
        def f(self):
            pass


def test17_name_qualname_module():
    # First, check what CPython does
    assert f.__module__ == "test_classes"
    assert f.__name__ == "f"
    assert f.__qualname__ == "f"
    assert MyClass.__name__ == "MyClass"
    assert MyClass.__qualname__ == "MyClass"
    assert MyClass.__module__ == "test_classes"
    assert MyClass.f.__name__ == "f"
    assert MyClass.f.__qualname__ == "MyClass.f"
    assert MyClass.f.__module__ == "test_classes"
    assert MyClass().f.__name__ == "f"
    assert MyClass().f.__qualname__ == "MyClass.f"
    assert MyClass().f.__module__ == "test_classes"
    assert MyClass.NestedClass.__name__ == "NestedClass"
    assert MyClass.NestedClass.__qualname__ == "MyClass.NestedClass"
    assert MyClass.NestedClass.__module__ == "test_classes"
    assert MyClass.NestedClass.f.__name__ == "f"
    assert MyClass.NestedClass.f.__qualname__ == "MyClass.NestedClass.f"
    assert MyClass.NestedClass.f.__module__ == "test_classes"

    # Now, check the extension module
    assert t.f.__module__ == "test_classes_ext"
    assert t.f.__name__ == "f"
    assert t.f.__qualname__ == "f"
    assert type(t.f).__module__ == "nanobind"
    assert type(t.f).__name__ == "nb_func"
    assert type(t.f).__qualname__ == "nb_func"
    assert t.MyClass.__name__ == "MyClass"
    assert t.MyClass.__qualname__ == "MyClass"
    assert t.MyClass.__module__ == "test_classes_ext"
    assert t.MyClass.f.__name__ == "f"
    assert t.MyClass.f.__qualname__ == "MyClass.f"
    assert t.MyClass.f.__module__ == "test_classes_ext"
    assert t.MyClass().f.__name__ == "f"
    assert t.MyClass().f.__qualname__ == "MyClass.f"
    assert t.MyClass().f.__module__ == "test_classes_ext"
    assert type(t.MyClass.f).__module__ == "nanobind"
    assert type(t.MyClass.f).__name__ == "nb_method"
    assert type(t.MyClass.f).__qualname__ == "nb_method"
    assert t.MyClass.NestedClass.__name__ == "NestedClass"
    assert t.MyClass.NestedClass.__qualname__ == "MyClass.NestedClass"
    assert t.MyClass.NestedClass.__module__ == "test_classes_ext"
    assert t.MyClass.NestedClass.f.__name__ == "f"
    assert t.MyClass.NestedClass.f.__qualname__ == "MyClass.NestedClass.f"
    assert t.MyClass.NestedClass.f.__module__ == "test_classes_ext"


def test18_static_properties():
    assert t.StaticProperties.value == 23
    t.StaticProperties.value += 1
    assert t.StaticProperties.value == 24
    assert t.StaticProperties.get() == 24
    assert t.StaticProperties2.get() == 24
    t.StaticProperties2.value = 50
    assert t.StaticProperties2.get() == 50
    assert t.StaticProperties.get() == 50

    # Deleting a static property without a deleter must raise
    with pytest.raises(AttributeError):
        del t.StaticProperties.value


@skip_on_pypy
def test19_static_properties_doc():
    import pydoc

    assert "Static property docstring" in pydoc.render_doc(t.StaticProperties2)


def test20_supplement():
    c = t.ClassWithSupplement()
    assert t.check_supplement(c)
    assert not t.check_supplement(t.Struct())


def test21_type_callback():
    o = t.ClassWithLen()
    assert len(o) == 123


def test22_low_level(clean):
    s1, s2, s3, s4 = t.test_lowlevel()
    assert s1.value() == 123 and s2.value() == 0 and s4.value() == 123
    assert s3.s1.value() == 123 and s3.s2.value() == 456
    assert s3.s1 is s4
    del s1
    del s2
    del s3
    collect()
    assert s4.value() == 123
    del s4
    assert_stats(
        value_constructed=3, copy_constructed=1, move_constructed=1, destructed=5
    )


def test23_handle_t(clean):
    assert (
        t.test_handle_t.__doc__
        == "test_handle_t(arg: test_classes_ext.Struct, /) -> object"
    )
    s = t.test_handle_t(t.Struct(5))
    assert s.value() == 5
    del s

    with pytest.raises(TypeError) as excinfo:
        t.test_handle_t("test")
    assert "incompatible function argument" in str(excinfo.value)
    assert_stats(value_constructed=1, destructed=1)


def test24_type_object_t(clean):
    assert (
        t.test_type_object_t.__doc__
        == "test_type_object_t(arg: type[test_classes_ext.Struct], /) -> object"
    )

    assert t.test_type_object_t(t.Struct) is t.Struct

    with pytest.raises(TypeError):
        t.test_type_object_t(t.Struct())

    with pytest.raises(TypeError):
        t.test_type_object_t(int)


def test25_none_arg():
    with pytest.raises(TypeError):
        t.none_0(None)
    with pytest.raises(TypeError):
        t.none_1(None)
    with pytest.raises(TypeError):
        t.none_2(arg=None)
    assert t.none_3(None) is True
    assert t.none_4(arg=None) is True
    assert t.none_0.__doc__ == "none_0(arg: test_classes_ext.Struct, /) -> bool"
    assert t.none_1.__doc__ == "none_1(arg: test_classes_ext.Struct, /) -> bool"
    assert t.none_2.__doc__ == "none_2(arg: test_classes_ext.Struct) -> bool"
    opt_struct = optional("test_classes_ext.Struct")
    assert t.none_3.__doc__ == f"none_3(arg: {opt_struct}, /) -> bool"
    assert t.none_4.__doc__ == f"none_4(arg: {opt_struct}) -> bool"


def test26_is_final():
    with pytest.raises(TypeError) as excinfo:

        class MyType(t.FinalType):
            pass

    assert "The type 'test_classes_ext.FinalType' prohibits subclassing!" in str(
        excinfo.value
    )


def test27_dynamic_attr(clean):
    l = [None] * 100
    for i in range(100):
        l[i] = t.StructWithAttr(i)

    # Create a big reference cycle..
    for i in range(100):
        l[i].prev = l[i - 1]
        l[i].next = l[i + 1 if i < 99 else 0]
        l[i].t = t.StructWithAttr
        l[i].self = l[i]

    for i in range(100):
        assert l[i].value() == i
        assert l[i].self.value() == i
        assert l[i].prev.value() == (i - 1 if i > 0 else 99)
        assert l[i].next.value() == (i + 1 if i < 99 else 0)

    del l

    assert_stats(value_constructed=100, destructed=100)


@skip_on_pypy
def test27b_bound_method_gc(clean):
    import gc

    o = t.StructWithAttr(1)
    bound = o.value
    assert gc.is_tracked(bound)

    # Create a cycle through the bound method (which holds a ref to 'o')
    o.cycle = bound
    del o, bound

    assert_stats(value_constructed=1, destructed=1)


def test28_copy_rvp():
    a = t.Struct.create_reference()
    b = t.Struct.create_copy()
    assert a is not b


def test29_pydoc():
    import pydoc

    assert "Some documentation" in pydoc.render_doc(t)

    # pydoc bypasses tp_getattro when looking up docstrings (see issue #1431)
    m = t.Dog("Rufus").what
    assert object.__getattribute__(m, "__doc__") == "what(self) -> str"
    assert "what(self) -> str" in pydoc.render_doc(m)


def test30_property_assignment_instance():
    s = t.PairStruct()
    s1 = t.Struct(123)
    s2 = t.Struct(456)
    s.s1 = s1
    s.s2 = s2
    assert s2 is not s.s2 and s1 is not s.s1
    assert s.s1.value() == 123
    assert s.s2.value() == 456
    assert s1.value() == 123
    assert s2.value() == 456


def test30b_property_policy_override():
    # A user-provided policy must take precedence over the implicit
    # 'reference_internal' policy of def_prop_ro
    s = t.PairStruct()
    c = s.s1_copy
    c.set_value(123)
    assert s.s1.value() != 123


# cpyext reference cycles are not supported, see https://foss.heptapod.net/pypy/pypy/-/issues/3849
@skip_on_pypy()
def test31_cycle():
    a = t.Wrapper()
    a.value = a
    del a
    collect()


def test32_type_checks():
    v1 = 5
    v2 = t.Struct()

    assert t.is_int_1(v1) and not t.is_int_1(v2)
    assert t.is_int_2(v1) and not t.is_int_2(v2)
    assert not t.is_struct(v1) and t.is_struct(v2)


def test33_polymorphic_downcast():
    assert isinstance(t.factory(), t.Base)
    assert isinstance(t.factory_2(), t.Base)
    assert isinstance(t.polymorphic_factory(), t.PolymorphicSubclass)
    assert isinstance(t.polymorphic_factory_2(), t.PolymorphicBase)


def test34_trampoline_optimization():
    class Rufus(t.Dog):
        def __init__(self):
            super().__init__("woof")

        def name(self):
            return "Rufus"

    for i in range(2):
        d1 = t.Dog("woof")
        d2 = Rufus()

        if i == 0:
            assert t.go(d1) == "Dog says woof"
            assert t.go(d2) == "Rufus says woof"

        old = t.Dog.name
        try:
            t.Dog.name = lambda self: "Max"

            assert t.go(d1) == "Dog says woof"
            assert t.go(d2) == "Rufus says woof"
        finally:
            t.Dog.name = old


def test35_method_introspection():
    obj = t.Struct(5)
    m = obj.value
    assert m() == m.__call__() == 5
    assert hash(m) == m.__hash__()
    assert repr(m) == m.__repr__()
    assert "bound_method" in repr(m)
    assert m.__self__ is obj
    assert m.__func__ is t.Struct.value
    # attributes not defined by nb_bound_method are forwarded to nb_method:
    assert m.__name__ == "value"
    assert m.__qualname__ == "Struct.value"
    assert m.__module__ == t.__name__
    assert m.__doc__ == t.Struct.value.__doc__ == "value(self) -> int"


def test38_pickle(clean):
    import pickle

    s = t.Struct(123)
    s2 = pickle.dumps(s, protocol=pickle.HIGHEST_PROTOCOL)
    s3 = pickle.loads(s2)
    assert s.value() == s3.value()
    del s, s3

    assert_stats(value_constructed=1, pickled=1, unpickled=1, destructed=2)


def test39_try_cast(clean):
    s = t.Struct(123)

    assert_stats(value_constructed=1)
    t.reset()

    rv, s2 = t.try_cast_1(s)
    assert rv is True and s2 is not s and s.value() == 123 and s2.value() == 123
    del s2
    assert_stats(
        default_constructed=1, move_constructed=2, copy_assigned=1, destructed=3
    )
    t.reset()

    rv, s2 = t.try_cast_1(None)
    assert rv is False and s2 is not s and s2.value() == 5
    del s2
    assert_stats(
        default_constructed=1, move_constructed=2, copy_assigned=0, destructed=3
    )
    t.reset()

    rv, s2 = t.try_cast_2(s)
    assert rv is True and s2 is not s and s.value() == 123 and s2.value() == 123
    del s2
    assert_stats(
        default_constructed=1, move_constructed=2, copy_assigned=1, destructed=3
    )
    t.reset()

    rv, s2 = t.try_cast_2(None)
    assert rv is False and s2 is not s and s2.value() == 5
    del s2
    assert_stats(
        default_constructed=1, move_constructed=2, copy_assigned=0, destructed=3
    )
    t.reset()

    rv, s2 = t.try_cast_3(s)
    assert rv is True and s2 is s and s.value() == 123
    del s2
    assert_stats()
    t.reset()

    rv, s2 = t.try_cast_3(None)
    assert rv is True and s2 is None
    del s2
    assert_stats(
        default_constructed=0, move_constructed=0, copy_assigned=0, destructed=0
    )
    t.reset()

    rv, s2 = t.try_cast_2(1)
    assert rv is False
    del s2
    assert_stats(default_constructed=1, move_constructed=2, destructed=3)
    t.reset()

    rv, s2 = t.try_cast_3(1)
    assert rv is False and s2 is None
    del s2
    assert_stats()
    t.reset()

    rv, s2 = t.try_cast_4(s)
    assert rv is False and s2 == 0
    rv, s2 = t.try_cast_4(123)
    assert rv is True and s2 == 123
    del s, s2

    assert_stats(destructed=1)


def test40_slots():
    if not hasattr(t, "test_slots"):
        pytest.skip()
    assert t.test_slots() == (True, True, True)


def test41_implicit_conversion_keep_alive():
    # Check that keep_alive references implicitly constructed arguments
    # as opposed to the original function arguments
    collect()
    t.get_destructed()

    a = t.Struct(5)
    b = t.get_incrementing_struct_value(a)
    d1 = t.get_destructed()
    assert b.value() == 106
    del a
    collect()
    d2 = t.get_destructed()
    collect()
    del b
    collect()
    d3 = t.get_destructed()
    assert d1 == []
    assert d2 == [5]
    assert d3 == [106, 6]


def test42_weak_references():
    import weakref
    import gc
    import time

    o = t.StructWithWeakrefs(42)
    w = weakref.ref(o)
    assert w() is o
    del o
    gc.collect()
    gc.collect()
    assert w() is None

    p = t.StructWithWeakrefsAndDynamicAttrs(43)
    p.a_dynamic_attr = 101
    w = weakref.ref(p)
    assert w() is p
    assert w().a_dynamic_attr == 101
    del p
    gc.collect()
    gc.collect()
    assert w() is None


def test43_union():
    u = t.Union()
    u.i = 42
    assert u.i == 42

    u.f = 2.125
    assert u.f == 2.125


def test44_dynamic_attr_has_dict():
    s = t.StructWithAttr(5)
    assert s.__dict__ == {}
    s.a_dynamic_attr = 101
    assert s.__dict__ == {"a_dynamic_attr": 101}


def test45_hidden_base():
    s = t.BoundDerived()
    assert s.value == 10
    s.value = 5
    assert s.prop == 5
    s.prop = 20
    assert s.value == 20
    assert s.get_answer() == 200
    assert s.polymorphic() == 20


def test46_custom_new():
    import gc

    assert t.UniqueInt.__new__.__doc__ == (
        "__new__(arg: object, /) -> object\n"
        "__new__(cls, value: int, /) -> UniqueInt\n"
        "__new__(cls, s: str) -> UniqueInt"
    )
    assert t.UniqueInt.__init__.__doc__ == (
        "__init__(self, arg: int, /) -> None\n"
        "__init__(self, s: str) -> None"
    )

    u1 = t.UniqueInt(10)
    assert u1.value() == 10 and u1.lookups() == 1

    u2 = t.UniqueInt(10)
    assert u1 is u2
    assert u1.lookups() == 2

    # test alternate constructor
    assert t.UniqueInt("10") is u1
    assert t.UniqueInt(s="10") is u1
    assert u1.lookups() == 4

    u3 = t.UniqueInt(20)
    assert u1 is not u3
    assert u3.value() == 20 and u3.lookups() == 1

    del u1
    assert u2.lookups() == 4
    assert u2 is t.UniqueInt(10)
    assert u2.lookups() == 5

    del u2
    gc.collect()
    gc.collect()

    u4 = t.UniqueInt(10)
    assert u4.value() == 10 and u4.lookups() == 1

    # As if unpickling:
    empty = t.UniqueInt.__new__(t.UniqueInt)
    with pytest.warns(RuntimeWarning, match="access an uninitialized instance"):
        with pytest.raises(TypeError):
            empty.value()

    # Make sure pickle support doesn't allow no-args construction by mistake
    with pytest.raises(TypeError):
        t.UniqueInt()

    with pytest.raises(RuntimeError):
        t.UniqueInt.__new__(int)

    # Make sure we do allow no-args construction for types that declare
    # such a __new__
    t.NewNone()
    assert t.NewDflt().value == 42
    assert t.NewDflt(10).value == 10
    assert t.NewStarPosOnly().value == 42
    assert t.NewStarPosOnly("hi").value == 43
    assert t.NewStarPosOnly(value=10).value == 10
    assert t.NewStarPosOnly("hi", "lo", value=10).value == 12
    assert t.NewStar().value == 42
    assert t.NewStar("hi").value == 43
    assert t.NewStar(value=10).value == 10
    assert t.NewStar("hi", "lo", value=10).value == 12
    assert t.NewStar(value=10, other="blah").value == 20

    # Make sure a Python class that derives from a C++ class that uses
    # nb::new_() can be instantiated producing the correct Python type
    class FancyInt(t.UniqueInt):
        @staticmethod
        def the_answer():
            return 42

        @property
        def value_as_string(self):
            return str(self.value())

    f1 = FancyInt(10)
    f2 = FancyInt(20)
    # The derived-type wrapping doesn't preserve Python identity...
    assert f1 is not FancyInt(10)
    # ... but does preserve C++ identity
    assert f1.lookups() == u4.lookups() == 3  # u4, f1, and anonymous
    assert f1.the_answer() == f2.the_answer() == 42
    assert f1.value_as_string == "10"
    assert f2.value_as_string == "20"

def test47_inconstructible():
    with pytest.raises(TypeError, match="no constructor defined"):
        t.Foo()

def test47b_state_warning_as_error():
    # When warnings are turned into errors, the state-error warning emitted
    # while casting an invalid instance must not leak a pending exception into
    # the dispatcher (which previously surfaced as a spurious SystemError).
    # The warning is instead reported through sys.unraisablehook.
    import warnings
    a = t.Int.__new__(t.Int)  # uninitialized
    b = t.Int(3)
    unraised = []
    old_hook = sys.unraisablehook
    sys.unraisablehook = lambda arg: unraised.append(arg.exc_value)
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", RuntimeWarning)
            # '__add__' fails to cast 'a' and must report NotImplemented cleanly
            with pytest.raises(TypeError, match="unsupported operand"):
                a + b
    finally:
        sys.unraisablehook = old_hook
    assert sys.exc_info() == (None, None, None)
    assert len(unraised) == 1
    assert isinstance(unraised[0], RuntimeWarning)
    assert "uninitialized instance" in str(unraised[0])

def test48_monekypatchable():
    # issue 750: how to monkeypatch __init__
    q = t.MonkeyPatchable()
    assert q.value == 123

    def my_init(self):
        t.MonkeyPatchable.custom_init(self)

    t.MonkeyPatchable.__init__ = my_init
    q = t.MonkeyPatchable()
    assert q.value == 456

def test49_static_property_override():
    assert t.StaticPropertyOverride.x == 42
    assert t.StaticPropertyOverride2.x == 43

def test50_weakref_with_slots_subclass():
    """
    Test that Python subclasses work correctly with nb::is_weak_referenceable()
    base classes. The nb::is_weak_referenceable() flag causes nanobind to
    install tp_traverse/tp_clear callbacks. When Python subclasses add their
    own instance dictionaries (e.g., via managed dicts on Python 3.12+),
    subtype_traverse calls our tp_traverse. We must only traverse dicts/weaklists
    created by nanobind, not those added by Python.

    Regression test for issue #1201.
    """
    import gc

    # Create a Python subclass with __slots__
    class SubClass(t.StructWithWeakrefsOnly):
        __slots__ = 'hello',

    # Create a sub-subclass without __slots__ (which should get a __dict__)
    class SubSubClass(SubClass):
        pass

    # This should not crash
    x = SubSubClass(42)
    x.bye = 'blah'
    assert x.value() == 42
    assert x.bye == 'blah'

    # Trigger GC to ensure inst_traverse doesn't crash
    gc.collect()
    gc.collect()

    # Clean up
    del x
    gc.collect()

def test51_constexpr_trampoline():
    class PyConstexprClass(t.ConstexprClass):
        def getInt(self):
            return 42

    c = PyConstexprClass(4)
    assert t.constexpr_call_getInt(c) == 42

def test52_noncopyable():
    assert t.PrivateNonCopyable.get_instance().get_int() == 42

def test53_never_destruct():
    r = t.NeverDestruct.make_ref()
    r.set_var(5)
    assert r.var() == 5


# Run the pooling lifecycle tests against both a plain type (gc=0) and a
# GC-tracked one (gc=1, dynamic_attr + weak-referenceable).
def _pooled(gc):
    if gc:
        return t.PooledGC, t.pooled_gc_reset, t.pooled_gc_stats
    return t.Pooled, t.pooled_reset, t.pooled_stats


# Object pooling relies on reference counting: releasing an instance parks the
# object immediately in 'tp_dealloc'. PyPy uses a tracing GC, so 'del' does not
# deterministically run the C++ destructor, breaking the lifecycle assertions.
@skip_on_pypy
@pytest.mark.parametrize("gc", [0, 1])
def test54_pooled(gc):
    cls, reset, stats = _pooled(gc)

    # Basic correctness through the pool fast path
    reset()
    a = cls(3)
    assert a.get() == 3 and a.value == 3
    c0, d0 = stats()
    assert c0 == 1 and d0 == 0

    # Releasing 'a' parks the object (capacity 4): the C++ destructor runs...
    addr = id(a)
    del a
    c1, d1 = stats()
    assert c1 == 1 and d1 == 1

    # ...and the next construction revives the SAME object (no realloc),
    # running a fresh C++ constructor. Identity (address) is reused.
    b = cls(7)
    assert id(b) == addr
    assert b.get() == 7   # no stale data from the previous occupant
    c2, d2 = stats()
    assert c2 == 2 and d2 == 1
    del b


@skip_on_pypy
@pytest.mark.parametrize("gc", [0, 1])
def test55_pooled_churn(gc):
    cls, reset, stats = _pooled(gc)

    # A hot alloc/free loop should keep reusing a tiny working set of objects
    # while construct/destruct run every iteration.
    reset()
    seen = set()
    for i in range(1000):
        x = cls(i)
        assert x.get() == i
        seen.add(id(x))
        del x
    c, d = stats()
    assert c == 1000 and d == 1000          # full C++ lifecycle each iteration
    assert len(seen) <= 4                   # but addresses come from the pool

    # Return-by-value (operator) also flows through the pool
    reset()
    p = cls(10)
    q = p + 5                               # returns a fresh instance by value
    assert q.get() == 15 and isinstance(q, cls)
    del p, q


@skip_on_pypy
@pytest.mark.parametrize("gc", [0, 1])
def test56_pooled_bounded(gc):
    cls, reset, stats = _pooled(gc)

    # Holding more live instances than the pool capacity (4) must be fine:
    # surplus objects are freed normally instead of parked.
    reset()
    items = [cls(i) for i in range(32)]
    assert [x.get() for x in items] == list(range(32))
    del items
    c, d = stats()
    assert c == 32 and d == 32


@skip_on_pypy
@pytest.mark.parametrize("gc", [0, 1])
def test59_pooled_threaded(gc, n_threads=8):
    cls, reset, stats = _pooled(gc)

    # Per-thread instance pools must work without locking under free-threading:
    # many threads concurrently construct/release pooled temporaries (including
    # return-by-value), and the exact C++ lifecycle balance must be preserved.
    n = 50000
    reset()

    def f():
        for i in range(n):
            a = cls(i)
            assert a.get() == i
            b = a + 5                 # return-by-value -> pool
            assert b.get() == i + 5
            del a, b

    parallelize(f, n_threads=n_threads)

    c, d = stats()
    # per iteration: ctor(a) + ctor(inside __add__) + move-ctor(by value) = 3
    expected = n_threads * n * 3
    assert c == expected and d == expected


# GC-specific guarantees the plain type can't exercise.
@skip_on_pypy
def test60_pooled_gc():
    import weakref, gc

    # A recycled instance must not inherit the previous occupant's __dict__
    t.pooled_gc_reset()
    p = t.PooledGC(1)
    p.extra = ["payload"]
    addr = id(p)
    del p
    q = t.PooledGC(2)
    assert id(q) == addr and not hasattr(q, "extra")
    del q

    # Parking an instance invalidates weak references to it
    r = t.PooledGC(5)
    wr = weakref.ref(r)
    assert wr() is r
    del r
    assert wr() is None

    # A reference cycle (via dynamic attrs) is still collected, not leaked
    t.pooled_gc_reset()
    x, y = t.PooledGC(1), t.PooledGC(2)
    x.peer, y.peer = y, x
    del x, y
    gc.collect()
    c, d = t.pooled_gc_stats()
    assert c == 2 and d == 2


# The only path where the collector traverses into a pooled object's C++ payload
# (PooledGC's built-in traverse only visits __dict__).
@skip_on_pypy
def test61_pooled_custom_traverse():
    import gc

    # Custom traverse reports the held reference; a revival starts clean
    t.pooled_tr_reset()
    sentinel = ["payload"]
    a = t.PooledTraverse(sentinel)
    assert sentinel in gc.get_referents(a)
    addr = id(a)
    del a
    b = t.PooledTraverse()
    assert id(b) == addr and b.get() is None
    del b

    # A cycle routed through the C++ payload is collected
    t.pooled_tr_reset()
    box = []
    q = t.PooledTraverse(box)
    box.append(q)
    del q, box
    gc.collect()
    c, d = t.pooled_tr_stats()
    assert c == 1 and d == 1


def test62_type_namespace():
    # 'type_dict' returns the writable namespace of a type
    d = t.type_dict(t.Struct)
    assert isinstance(d, dict) and "value_plus" in d
    assert t.type_dict(t.Struct) is d

    class Sub(t.Struct):
        pass

    t.type_dict_insert(Sub, "injected", 5)
    assert Sub.injected == 5

    # Inherited entries are not part of the namespace, but visible to a lookup
    assert "value" in t.type_dict(t.StaticProperties)
    assert "value" not in t.type_dict(t.StaticProperties2)
    assert t.type_lookup(t.StaticProperties2, "value") is \
           t.type_dict(t.StaticProperties)["value"]

    # The lookup returns raw entries without invoking the descriptor protocol
    assert t.Struct.static_ro == 42
    assert type(t.type_lookup(t.Struct, "static_ro")).__name__ == \
           "nb_static_property"

    # It also does not fall back to the metaclass
    assert t.Struct.__name__ == "Struct"
    assert t.type_lookup(t.Struct, "__name__") is None
    assert t.type_lookup(t.Struct, "does_not_exist") is None

    # Python string keys produce the same results
    for name in ("static_ro", "__name__", "does_not_exist"):
        assert t.type_lookup_key(t.Struct, name) is t.type_lookup(t.Struct, name)


def test63_freeze():
    if t.freeze_supported():
        with pytest.raises(TypeError):
            t.Frozen.extra = 1
        with pytest.raises(TypeError):
            t.Frozen2.extra = 1

        # Freezing requires that all base classes are immutable
        with pytest.raises(TypeError, match="mutable base"):
            t.freeze_type(t.StaticProperties2)
    else:
        assert not t.freeze_type(t.StaticProperties2)
        t.Frozen.extra = 1
        del t.Frozen.extra

    # Instances and subclasses remain usable either way
    v = t.Frozen()
    v.value = 5
    assert v.value == 5

    class Sub(t.Frozen):
        pass

    assert Sub().value == 3


def test64_inst_dict():
    s = t.StructWithAttr(5)
    d = t.inst_dict(s)
    assert d == {} and s.__dict__ is d

    s.attr = 10
    assert d["attr"] == 10
    t.inst_dict_insert(s, "attr_2", 11)
    assert s.attr_2 == 11

    # A Python subclass holds attributes even when the base type does not
    # declare 'nb::dynamic_attr'
    class Sub(t.Struct):
        pass

    x = Sub(2)
    t.inst_dict_insert(x, "attr", 12)
    assert x.attr == 12 and x.__dict__ == {"attr": 12}

    # The function also accepts objects unrelated to nanobind. Such instances
    # may keep their attributes in a managed dictionary that only materializes
    # when it is requested.
    class Plain:
        def __init__(self):
            self.attr = 13

    y = Plain()
    d = t.inst_dict(y)
    assert d == {"attr": 13} and y.__dict__ is d
    t.inst_dict_insert(y, "attr_2", 14)
    assert y.attr_2 == 14

    # Objects that cannot store attributes report an invalid dictionary
    # (PyPy equips every instance with one)
    if not is_pypy:
        assert t.inst_dict(t.Struct(1)) is None
        assert t.inst_dict(object()) is None and t.inst_dict(1) is None


def test65_init_subclass_setattr():
    # '__init_subclass__' and '__set_name__' observe the new class before the
    # metaclass 'tp_init' slot runs. The nanobind type record must already be
    # complete at this point.
    class BaseWithInitSubclass(t.Animal):
        def __init_subclass__(cls, **kwargs):
            super().__init_subclass__(**kwargs)
            cls.foo = 123

    class Derived(BaseWithInitSubclass):
        pass

    assert Derived.foo == 123

    class Descriptor:
        def __set_name__(self, owner, name):
            owner.bar = name

    class Derived2(t.Animal):
        descr = Descriptor()

    assert Derived2.bar == "descr"

    with pytest.raises(TypeError, match="requires a nanobind base type"):
        class Derived3(metaclass=type(t.Animal)):
            pass


def test66_uninitialized_type_use():
    # Instantiation from '__init_subclass__' / '__set_name__', and types
    # created via 'type.__new__()', which skips the metaclass 'tp_init' slot
    class BaseWithInitSubclass(t.Animal):
        def __init_subclass__(cls, **kwargs):
            super().__init_subclass__(**kwargs)
            cls.inst = cls()

    class Derived(BaseWithInitSubclass):
        pass

    assert isinstance(Derived.inst, Derived)
    assert Derived.inst.name() == "Animal"

    class Descriptor:
        def __set_name__(self, owner, name):
            owner.inst = owner()

    class Derived2(t.Animal):
        descr = Descriptor()

    assert isinstance(Derived2.inst, Derived2)

    meta = type(t.Animal)
    Derived3 = type.__new__(meta, "Derived3", (t.Animal,), {})
    Derived3.baz = 1
    assert Derived3.baz == 1 and isinstance(Derived3(), t.Animal)

    # 'type.__new__()' cannot be intercepted, the error surfaces on first use
    Derived4 = type.__new__(meta, "Derived4", (t.FinalType,), {})
    with pytest.raises(TypeError, match="prohibits subclassing"):
        Derived4()
    with pytest.raises(TypeError, match="prohibits subclassing"):
        Derived4.foo = 1

    # Chains of types whose first use happens via a subclass
    Derived5 = type.__new__(meta, "Derived5", (t.Animal,), {})

    class Derived6(Derived5):
        pass

    assert isinstance(Derived6(), Derived5)

    class BaseWithCompanion(t.Animal):
        def __init_subclass__(cls, **kwargs):
            super().__init_subclass__(**kwargs)
            if cls.__name__ != "Companion":
                cls.companion = type("Companion", (cls,), {})()

    class Derived7(BaseWithCompanion):
        pass

    assert isinstance(Derived7.companion, Derived7)
    assert Derived7.companion.name() == "Animal"


def test67_implicit_self_annotation():
    # 'self' is the only parameter, and it carries an implicit annotation, so
    # the function record ends up without any argument records
    assert t.OptionalNoneTest().optional_self() is True


def test68_trampoline_invalidate_subclasses():
    """Invalidate cached missing overrides in ordinary nanobind descendants
    when a Python base class is patched, including on PyPy."""
    class Base(t.Dog):
        pass

    class Sub(Base):
        pass

    obj = Sub("hello")
    assert t.go(obj) == "Dog says hello"
    Base.name = lambda self: "patched"
    assert t.go(obj) == "patched says hello"
    del Base.name
    assert t.go(obj) == "Dog says hello"


@pytest.mark.parametrize("order", list(permutations(range(3))))
def test69_multiple_inheritance(order):
    """Combine two mixins with a bound class in every order, preserving its MRO
    and conversion to C++ base classes, including after further subclassing."""
    class MixinA:
        def __init__(self, value):
            self.a = value

        def extra(self):
            return self.a + self.b

    class MixinB:
        def __init__(self, value):
            self.b = value

    bases = (MixinA, MixinB, t.Dog)
    bases = tuple(bases[i] for i in order)

    class Mixed(*bases):
        def __init__(self):
            t.Dog.__init__(self, "hello")
            MixinA.__init__(self, 10)
            MixinB.__init__(self, 20)

    expected_mro = list(bases)
    expected_mro.insert(expected_mro.index(t.Dog) + 1, t.Animal)
    assert Mixed.__mro__ == (Mixed, *expected_mro, object)
    assert Mixed.__base__ is t.Dog

    obj = Mixed()
    assert obj.extra() == 30
    assert all(isinstance(obj, b) for b in (*bases, t.Animal))
    assert t.animal_passthrough(obj) is obj
    assert t.dog_passthrough(obj) is obj
    assert t.go(obj) == "Dog says hello"

    class EmptyMixin:
        __slots__ = ()

    class Further(EmptyMixin, Mixed):
        pass

    obj = Further()
    assert obj.extra() == 30 and t.animal_passthrough(obj) is obj


def test70_multiple_inheritance_super():
    """Follow cooperative mixin initializers and virtual overrides through super();
    a bound constructor terminates the initializer chain."""
    class MixinA:
        def __init__(self, *args, **kwargs):
            self.a = 10
            super().__init__(*args, **kwargs)

        def name(self):
            return "A " + super().name()

        def extra(self):
            return self.a + super().extra()

    class MixinB:
        def __init__(self, *args, **kwargs):
            self.b = 20
            super().__init__(*args, **kwargs)

        def name(self):
            return "B " + super().name()

        def extra(self):
            return self.b

    class Mixed(MixinA, MixinB, t.Dog):
        pass

    obj = Mixed("hello")
    assert (obj.a, obj.b) == (10, 20)
    assert obj.extra() == 30
    assert t.go(obj) == "A B Dog says hello"

    class BoundFirst(t.Dog, MixinA, MixinB):
        pass

    obj = BoundFirst("hello")
    assert not hasattr(obj, "a") and not hasattr(obj, "b")
    assert t.go(obj) == "Dog says hello"


@pytest.mark.parametrize("base", [t.Struct, t.StructWithAttr,
                                  t.StructWithWeakrefs,
                                  t.StructWithWeakrefsAndDynamicAttrs])
def test71_multiple_inheritance_gc(clean, base):
    """Collect cycles in mixin dictionaries and subclass slots, releasing weak
    references and destroying the C++ instance exactly once."""
    import weakref

    class Mixin:
        pass

    class Mixed(Mixin, base):
        __slots__ = ("peer",)

    obj = Mixed(42)
    assert obj.value() == 42
    obj.peer = obj
    obj.cycle = obj
    ref = weakref.ref(obj)
    del obj
    collect()
    assert ref() is None
    assert_stats(value_constructed=1, destructed=1)


def test72_multiple_inheritance_errors():
    """Reject multiple nanobind bases, conflicting native layouts, and mixins
    combined with a bound class that prohibits subclassing."""
    class Left(t.Struct):
        pass

    class Right(t.Struct):
        pass

    # Python accepts these compatible layouts, nanobind rejects them
    for bases in ((t.Dog, t.Animal), (Left, Right)):
        with pytest.raises(TypeError, match="multiple nanobind bases"):
            type("MultipleBases", bases, {})

    class SlottedMixin:
        __slots__ = ("state",)

    for bases in ((t.Struct, t.Dog), (list, t.Struct),
                  (SlottedMixin, t.Struct), (t.Struct, SlottedMixin)):
        with pytest.raises(TypeError):
            type("ConflictingLayout", bases, {})

    class Mixin:
        pass

    with pytest.raises(TypeError, match="prohibits subclassing"):
        class Final(Mixin, t.FinalType):
            pass


def test73_multiple_inheritance_early_init():
    """Allow mixin instances in class hooks and initialize deferred type records,
    while still rejecting invalid bases when the metaclass initializer is skipped."""
    class Mixin:
        def __init_subclass__(cls, **kwargs):
            super().__init_subclass__(**kwargs)
            cls.inst = cls("hello")

    class Mixed(Mixin, t.Dog):
        pass

    assert t.go(Mixed.inst) == "Dog says hello"
    del Mixed.inst

    class Descriptor:
        def __set_name__(self, owner, name):
            owner.inst = owner("hello")

    class PlainMixin:
        pass

    bases = (PlainMixin, t.Dog)

    class WithDescriptor(*bases):
        descr = Descriptor()

    assert t.go(WithDescriptor.inst) == "Dog says hello"
    del WithDescriptor.inst

    # Bypass the metaclass initializer, including for the nanobind base.
    meta = type(t.Dog)
    Deferred = type.__new__(meta, "Deferred", bases, {})

    Deferred2 = type.__new__(meta, "Deferred2", (Deferred,), {})
    assert t.go(Deferred2("hello")) == "Dog says hello"

    Invalid = type.__new__(meta, "Invalid", (t.Dog, t.Animal), {})
    with pytest.raises(TypeError, match="multiple nanobind bases"):
        Invalid("hello")
    with pytest.raises(TypeError, match="multiple nanobind bases"):
        Invalid.attr = 1


def test74_multiple_inheritance_monkeypatch():
    """Observe replaced and deleted mixin overrides, along with changes made
    through the nanobind subclass, on a mixed class and its descendants."""
    class Mixin:
        def name(self):
            return "mixin"

    class Named:
        def name(self):
            return "named"

    class Mixed(Mixin, t.Dog):
        pass

    class Further(Mixed):
        pass

    objects = [Mixed("hello"), Further("hello")]

    def check(name):
        for obj in objects:
            assert t.go(obj) == name + " says hello"

    check("mixin")
    Mixin.name = lambda self: "replaced"
    check("replaced")
    del Mixin.name
    check("Dog")
    Mixed.name = lambda self: "mixed"
    check("mixed")
    del Mixed.name
    check("Dog")
    Mixed.__bases__ = (Named, t.Dog)
    check("named")
