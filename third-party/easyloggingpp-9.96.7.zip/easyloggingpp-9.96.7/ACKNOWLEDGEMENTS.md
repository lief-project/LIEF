# Acknowledgements
This file contains list of contributors and acknowledgement of their efforts in making this library better especially by making acceptable code changes.

If we have missed your name please feel free to add it with contribution link.

| **Github User**                      |          **Contribution**        |
|--------------------------------------|----------------------------------|
| [@aparajita](https://github.com/aparajita)                           | [Separated out .h and .cc file](https://github.com/muflihun/easyloggingpp/pulls?q=is%3Apr+author%3Aaparajita)    |
| [@adah1972](https://github.com/adah1972)                            | [A lot of contributions](https://github.com/muflihun/easyloggingpp/pulls?q=is%3Apr+author%3Aadah1972) |
| [@miguelmartin75](https://github.com/miguelmartin75)                      | [Issue #11](https://github.com/muflihun/easyloggingpp/issues/11), [PR #16](https://github.com/muflihun/easyloggingpp/pull/16) |
| [@moneromooo-monero](https://github.com/moneromooo-monero)                   | [A lot of contributions](https://github.com/muflihun/easyloggingpp/pulls?q=is%3Apr+author%3Amoneromooo-monero)|
| [@MonsieurNicolas](https://github.com/MonsieurNicolas)                     | [PR #593](https://github.com/muflihun/easyloggingpp/pull/593) |
| [@acowley](https://github.com/acowley)                             | [PR #593](https://github.com/muflihun/easyloggingpp/pull/577) |
| [@rggjan](https://github.com/rggjan)                              | [PR 561](https://github.com/muflihun/easyloggingpp/pull/561) |
| [@sgtcodfish](https://github.com/sgtcodfish) | Support for emscripten |
