echo "Running '$1'..."
./$1
echo "Finished '$1'"
echo
