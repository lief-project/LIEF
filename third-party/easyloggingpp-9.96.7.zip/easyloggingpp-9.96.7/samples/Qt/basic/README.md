###### Easylogging++ Qt Samples

This sample contains:
 * Qt containers
 * QThread based multi-threading
