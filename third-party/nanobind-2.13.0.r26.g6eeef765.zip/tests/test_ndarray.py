import test_ndarray_ext as t
import pytest
import warnings
import importlib
from common import collect, skip_on_pypy

try:
    import numpy as np
    def needs_numpy(x):
        return x
except:
    needs_numpy = pytest.mark.skip(reason="NumPy is required")

try:
    import torch
    def needs_torch(x):
        return x
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        def needs_torch_mps(x):
            return x
    else:
        needs_torch_mps = pytest.mark.skip(reason="PyTorch MPS is required")
except:
    needs_torch = pytest.mark.skip(reason="PyTorch is required")
    needs_torch_mps = pytest.mark.skip(reason="PyTorch MPS is required")

try:
    import cupy as cp
    def needs_cupy(x):
        return x
except:
    needs_cupy = pytest.mark.skip(reason="CuPy is required")

try:
    import mlx.core as mx
    def needs_mlx(x):
        return x
except:
    needs_mlx = pytest.mark.skip(reason="MLX is required")


@needs_numpy
def test01_metadata():
    a = np.zeros(shape=())
    assert t.get_shape(a) == []

    if hasattr(a, '__dlpack__'):
        b = a.__dlpack__()
        assert t.get_shape(b) == []
    else:
        b = None

    with pytest.raises(TypeError) as excinfo:
        # Capsule can only be consumed once
        assert t.get_shape(b) == []
    assert 'incompatible function arguments' in str(excinfo.value)

    a = np.zeros(shape=(3, 4, 5), dtype=np.float64)
    assert t.get_is_valid(a)
    assert t.get_shape(a) == [3, 4, 5]
    assert t.get_size(a) == 60
    assert t.get_nbytes(a) == 60*8
    assert t.get_itemsize(a) == 8
    assert t.check_shape_ptr(a)
    assert t.check_stride_ptr(a)
    if hasattr(a, '__dlpack__'):
        assert t.get_shape(a.__dlpack__()) == [3, 4, 5]
    assert not t.check_float(np.array([1], dtype=np.bool_)) and \
           not t.check_float(np.array([1], dtype=np.uint32)) and \
               t.check_float(np.array([1], dtype=np.float32))
    assert not t.check_bool(np.array([1], dtype=np.uint32)) and \
           not t.check_bool(np.array([1], dtype=np.float32)) and \
               t.check_bool(np.array([1], dtype=np.bool_))

    assert not t.get_is_valid(None)
    assert t.get_size(None) == 0
    assert t.get_nbytes(None) == 0
    assert t.get_itemsize(None) == 0


def test02_docstr():
    assert t.pass_uint32.__doc__ == "pass_uint32(array: ndarray[dtype=uint32]) -> None"
    assert t.get_shape.__doc__ == "get_shape(array: ndarray[writable=False]) -> list"
    assert t.pass_float32.__doc__ == "pass_float32(array: ndarray[dtype=float32]) -> None"
    assert t.pass_complex64.__doc__ == "pass_complex64(array: ndarray[dtype=complex64]) -> None"
    assert t.pass_bool.__doc__ == "pass_bool(array: ndarray[dtype=bool]) -> None"
    assert t.pass_float32_shaped.__doc__ == "pass_float32_shaped(array: ndarray[dtype=float32, shape=(3, *, 4)]) -> None"
    assert t.pass_float32_shaped_ordered.__doc__ == "pass_float32_shaped_ordered(array: ndarray[dtype=float32, shape=(*, *, 4), order='C']) -> None"
    assert t.check_device.__doc__ == ("check_device(arg: ndarray[device='cpu'], /) -> str\n"
                                      "check_device(arg: ndarray[device='cuda'], /) -> str")


@needs_numpy
def test03_constrain_dtype():
    a_u32 = np.array([1], dtype=np.uint32)
    a_f32 = np.array([1], dtype=np.float32)
    a_cf64 = np.array([1+1j], dtype=np.complex64)
    a_bool = np.array([1], dtype=np.bool_)

    t.pass_uint32(a_u32)
    t.pass_float32(a_f32)
    t.pass_complex64(a_cf64)
    t.pass_complex64_const(a_cf64)
    t.pass_bool(a_bool)

    a_f32_const = a_f32.copy()
    a_f32_const.flags.writeable = False
    t.pass_float32_const(a_f32_const)

    a_cf64_const = a_cf64.copy()
    a_cf64_const.flags.writeable = False
    t.pass_complex64_const(a_cf64_const)

    with pytest.raises(TypeError) as excinfo:
        t.pass_uint32(a_f32)
    assert 'incompatible function arguments' in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        t.pass_float32(a_u32)
    assert 'incompatible function arguments' in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        t.pass_complex64(a_u32)
    assert 'incompatible function arguments' in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        t.pass_bool(a_u32)
    assert 'incompatible function arguments' in str(excinfo.value)


@needs_numpy
def test04_constrain_shape():
    t.pass_float32_shaped(np.zeros((3, 0, 4), dtype=np.float32))
    t.pass_float32_shaped(np.zeros((3, 5, 4), dtype=np.float32))

    with pytest.raises(TypeError) as excinfo:
        t.pass_float32_shaped(np.zeros((3, 5), dtype=np.float32))

    with pytest.raises(TypeError) as excinfo:
        t.pass_float32_shaped(np.zeros((2, 5, 4), dtype=np.float32))

    with pytest.raises(TypeError) as excinfo:
        t.pass_float32_shaped(np.zeros((3, 5, 6), dtype=np.float32))

    with pytest.raises(TypeError) as excinfo:
        t.pass_float32_shaped(np.zeros((3, 5, 4, 6), dtype=np.float32))


def test05_bytes():
    a = bytearray(range(10))
    assert t.get_is_valid(a)
    assert t.get_shape(a) == [10]
    assert t.get_size(a) == 10
    assert t.get_nbytes(a) == 10
    assert t.get_itemsize(a) == 1
    assert t.check_order(a) == 'C'
    b = b'hello'  # immutable
    assert t.get_is_valid(b)
    assert t.get_shape(b) == [5]


@needs_numpy
def test06_constrain_order_numpy():
    assert t.check_order(np.zeros((3, 5, 4, 6), order='C')) == 'C'
    assert t.check_order(np.zeros((3, 5, 4, 6), order='F')) == 'F'
    assert t.check_order(np.zeros((3, 5, 4, 6), order='C')[:, 2, :, :]) == '?'
    assert t.check_order(np.zeros((3, 5, 4, 6), order='F')[:, 2, :, :]) == '?'


@needs_torch
@pytest.mark.filterwarnings
def test07_constrain_order_pytorch():
    try:
        c = torch.zeros(3, 5)
        c.__dlpack__()
    except:
        pytest.skip('pytorch is missing')

    f = c.t().contiguous().t()
    assert t.check_order(c) == 'C'
    assert t.check_order(f) == 'F'
    assert t.check_order(c[:, 2:5]) == '?'
    assert t.check_order(f[1:3, :]) == '?'
    assert t.check_device(torch.zeros(3, 5)) == 'cpu'
    if torch.cuda.is_available():
        assert t.check_device(torch.zeros(3, 5, device='cuda')) == 'cuda'


def test08_write_bytes_from_cpp():
    a = bytearray(10)
    t.initialize(a)
    assert a == bytearray(range(10))
    b = b'helloHello'  # ten immutable bytes
    with pytest.raises(TypeError) as excinfo:
        t.initialize(b)
    assert 'incompatible function arguments' in str(excinfo.value)


@needs_numpy
def test09_write_numpy_from_cpp():
    x = np.zeros(10, dtype=np.float32)
    t.initialize(x)
    assert np.all(x == np.arange(10, dtype=np.float32))

    x = np.zeros((10, 3), dtype=np.float32)
    t.initialize(x)
    assert np.all(x == np.arange(30, dtype=np.float32).reshape(10, 3))


@needs_numpy
def test10_implicit_conversion():
    t.implicit(np.zeros((2, 2), dtype=np.uint32))
    t.implicit(np.zeros((2, 2, 10), dtype=np.float32)[:, :, 4])
    t.implicit(np.zeros((2, 2, 10), dtype=np.uint32)[:, :, 4])
    t.implicit(np.zeros((2, 2, 10), dtype=np.bool_)[:, :, 4])

    with pytest.raises(TypeError) as excinfo:
        t.noimplicit(np.zeros((2, 2), dtype=np.bool_))

    with pytest.raises(TypeError) as excinfo:
        t.noimplicit(np.zeros((2, 2), dtype=np.uint32))

    with pytest.raises(TypeError) as excinfo:
        t.noimplicit(np.zeros((2, 2, 10), dtype=np.float32)[:, :, 4])


@needs_numpy
def test10b_implicit_conversion_unusual_module():
    # The implicit-conversion path in ndarray_import() inspects the array
    # type's '__module__' attribute. Make sure it deals gracefully with an
    # attribute whose value is computed dynamically (so that the underlying
    # string is a freshly created temporary), matching a known framework.
    class DynMeta(type):
        @property
        def __module__(cls):
            return "".join(["nu", "mpy", ".dyn"])  # fresh 'numpy*' string

    class DynModArray(np.ndarray, metaclass=DynMeta):
        pass

    a = np.zeros((2, 2), dtype=np.uint32).view(DynModArray)
    assert t.implicit(a) == 0


@needs_torch
def test11_implicit_conversion_pytorch():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            c = torch.zeros(3, 5)
            c.__dlpack__()
        except:
            pytest.skip('pytorch is missing')

    t.implicit(torch.zeros(2, 2, dtype=torch.int32))
    t.implicit(torch.zeros(2, 2, 10, dtype=torch.float32)[:, :, 4])
    t.implicit(torch.zeros(2, 2, 10, dtype=torch.int32)[:, :, 4])

    with pytest.raises(TypeError) as excinfo:
        t.noimplicit(torch.zeros(2, 2, dtype=torch.int32))

    with pytest.raises(TypeError) as excinfo:
        t.noimplicit(torch.zeros(2, 2, 10, dtype=torch.float32)[:, :, 4])


@needs_numpy
def test12_process_image():
    x = np.arange(120, dtype=np.ubyte).reshape(8, 5, 3)
    t.process(x)
    assert np.all(x == np.arange(0, 240, 2, dtype=np.ubyte).reshape(8, 5, 3))


def test13_destroy_capsule():
    collect()
    dc = t.destruct_count()
    capsule = t.return_no_framework()
    assert 'dltensor' in repr(capsule)
    assert 'versioned' not in repr(capsule)
    assert t.destruct_count() == dc
    del capsule
    collect()
    assert t.destruct_count() - dc == 1


@needs_numpy
def test14_consume_numpy():
    collect()
    class wrapper:
        def __init__(self, value):
            self.value = value
        def __dlpack__(self):
            return self.value
    dc = t.destruct_count()
    capsule = t.return_no_framework()
    if hasattr(np, '_from_dlpack'):
        x = np._from_dlpack(wrapper(capsule))
    elif hasattr(np, 'from_dlpack'):
        x = np.from_dlpack(wrapper(capsule))
    else:
        pytest.skip('your version of numpy is too old')
    del capsule
    collect()
    assert x.shape == (2, 4)
    assert np.all(x == [[1, 2, 3, 4], [5, 6, 7, 8]])
    assert t.destruct_count() == dc
    del x
    collect()
    assert t.destruct_count() - dc == 1


@needs_numpy
def test15_passthrough_numpy():
    a = t.ret_numpy()
    b = t.passthrough(a)
    assert a is b

    a = np.array([1, 2, 3])
    b = t.passthrough(a)
    assert a is b

    a = None
    with pytest.raises(TypeError) as excinfo:
        b = t.passthrough(a)
    assert 'incompatible function arguments' in str(excinfo.value)
    b = t.passthrough_arg_none(a)
    assert a is b


@needs_torch
def test16_passthrough_torch():
    a = t.ret_pytorch()
    b = t.passthrough(a)
    assert a is b

    a = torch.tensor([1, 2, 3])
    b = t.passthrough(a)
    assert a is b

    a = None
    with pytest.raises(TypeError) as excinfo:
        b = t.passthrough(a)
    assert 'incompatible function arguments' in str(excinfo.value)
    b = t.passthrough_arg_none(a)
    assert a is b


@needs_numpy
def test17_return_numpy():
    collect()
    dc = t.destruct_count()
    x = t.ret_numpy()
    assert x.shape == (2, 4)
    assert x.flags.writeable
    assert np.all(x == [[1, 2, 3, 4], [5, 6, 7, 8]])
    del x
    collect()
    assert t.destruct_count() - dc == 1


@needs_torch
def test18_return_pytorch():
    try:
        c = torch.zeros(3, 5)
    except:
        pytest.skip('pytorch is missing')
    collect()
    dc = t.destruct_count()
    x = t.ret_pytorch()
    assert x.shape == (2, 4)
    assert torch.all(x == torch.tensor([[1, 2, 3, 4], [5, 6, 7, 8]]))
    del x
    collect()
    assert t.destruct_count() - dc == 1


@needs_mlx
def test18b_return_mlx():
    collect()
    dc = t.destruct_count()
    x = t.ret_mlx()
    assert isinstance(x, mx.array)
    assert x.shape == (2, 4)
    assert x.dtype == mx.float32
    expect = mx.array([[1, 2, 3, 4], [5, 6, 7, 8]], dtype=mx.float32)
    assert bool(mx.all(x == expect))
    # mlx.core.array() copies, so the source buffer is released immediately
    # rather than on `del` (as with the zero-copy dlpack frameworks).
    collect()
    assert t.destruct_count() - dc == 1
    del x
    collect()
    assert t.destruct_count() - dc == 1


@skip_on_pypy
def test19_return_memview():
    collect()
    dc = t.destruct_count()
    x = t.ret_memview()
    assert isinstance(x, memoryview)
    assert x.itemsize == 8
    assert x.ndim == 2
    assert x.shape == (2, 4)
    assert x.strides == (32, 8)  # in bytes
    assert x.tolist() == [[1, 2, 3, 4], [5, 6, 7, 8]]
    del x
    collect()
    assert t.destruct_count() - dc == 1


@skip_on_pypy
def test19b_buffer_protocol_flags():
    import struct
    import tempfile
    import os

    # The buffer-protocol exporter must honor the request flags.

    # (a) A writable request against a read-only ndarray must be refused.
    ro = t.ret_memview_ro().obj
    assert memoryview(ro).readonly
    assert memoryview(ro).tolist() == [[1, 2, 3, 4], [5, 6, 7, 8]]

    data = struct.pack("8f", 100, 200, 300, 400, 500, 600, 700, 800)
    fd, path = tempfile.mkstemp()
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        # readinto() requests a writable buffer; this must not mutate the
        # read-only array (the request is rejected during getbuffer()).
        with open(path, "rb") as f:
            with pytest.raises((BufferError, TypeError)):
                f.readinto(ro)
    finally:
        os.remove(path)
    assert memoryview(ro).tolist() == [[1, 2, 3, 4], [5, 6, 7, 8]]

    # (b) A non-strided request against an F-contiguous (non-C-contiguous)
    # ndarray must be refused -- otherwise the consumer reads wrong elements.
    fobj = t.ret_memview_f().obj
    assert memoryview(fobj).tolist() == [[1, 3, 5, 7], [2, 4, 6, 8]]
    with pytest.raises(BufferError):
        struct.unpack_from("8f", fobj)

    # A non-strided request on C-contiguous data still works.
    cobj = t.ret_memview().obj
    assert struct.unpack_from("8d", cobj) == (1, 2, 3, 4, 5, 6, 7, 8)


def test19c_export_ownerless_refused():
    # Returning an ownerless ndarray under a policy that requires a copy is
    # refused for frameworks without a copy method, instead of silently
    # returning a view of freed memory.
    for fn in (t.ret_memview_noowner, t.ret_array_api_noowner,
               t.ret_noframework_noowner):
        with pytest.raises(RuntimeError, match="not supported for this framework"):
            fn()


@needs_numpy
def test20_return_array_api():
    collect()
    dc = t.destruct_count()
    obj = t.ret_array_api()
    assert obj.__dlpack_device__() == (1, 0)  # (type == CPU, id == 0)
    capsule = obj.__dlpack__()
    assert 'dltensor' in repr(capsule)
    assert 'versioned' not in repr(capsule)
    capsule = obj.__dlpack__(max_version=None)
    assert 'dltensor' in repr(capsule)
    assert 'versioned' not in repr(capsule)
    capsule = obj.__dlpack__(max_version=(0, 0))  # (major == 0, minor == 0)
    assert 'dltensor' in repr(capsule)
    assert 'versioned' not in repr(capsule)
    capsule = obj.__dlpack__(max_version=(1, 0))  # (major == 1, minor == 0)
    assert 'dltensor_versioned' in repr(capsule)
    with pytest.raises(TypeError) as excinfo:
        capsule = obj.__dlpack__(0)
    assert 'does not accept positional arguments' in str(excinfo.value)
    del obj
    collect()
    assert t.destruct_count() == dc
    del capsule
    collect()
    assert t.destruct_count() - dc == 1
    dc += 1

    obj = t.ret_array_api()  # obj also supports the buffer protocol
    mv = memoryview(obj)
    assert mv.tolist() == [[1, 2, 3, 4], [5, 6, 7, 8]]
    del obj
    collect()
    assert t.destruct_count() == dc
    del mv
    collect()
    assert t.destruct_count() - dc == 1
    dc += 1

    if (hasattr(np, '__array_api_version__') and
        np.__array_api_version__ >= '2024'):
        obj = t.ret_array_api()
        # copy=True is surfaced as a BufferError by NumPy
        with pytest.raises(BufferError):
            np.from_dlpack(obj, copy=True)
        x = np.from_dlpack(obj)
        del obj
        collect()
        assert t.destruct_count() == dc
        assert x.shape == (2, 4)
        assert x.flags.writeable
        assert np.all(x == [[1, 2, 3, 4], [5, 6, 7, 8]])
        del x
        collect()
        assert t.destruct_count() - dc == 1
        dc += 1

    obj = t.ret_array_api_byte_offset()
    assert t.inspect_byte_offset(obj) == (1, 0, 2, 2, 4, 8)
    mv = memoryview(obj)
    assert mv.tolist() == [[2, 3, 4, 5], [6, 7, 8, 9]]
    del obj
    collect()
    assert t.destruct_count() == dc
    del mv
    collect()
    assert t.destruct_count() - dc == 1
    dc += 1

    if (hasattr(np, '__array_api_version__') and
        np.__array_api_version__ >= '2024'):
        obj = t.ret_array_api_byte_offset()
        x = np.from_dlpack(obj)
        del obj
        collect()
        assert t.destruct_count() == dc
        assert x.shape == (2, 4)
        assert np.all(x == [[2, 3, 4, 5], [6, 7, 8, 9]])
        del x
        collect()
        assert t.destruct_count() - dc == 1


def test20a_dlpack_copy_device_kwargs():
    obj = t.ret_array_api()

    # copy=False/None are honored, copy=True cannot be satisfied (aliasing)
    assert 'dltensor' in repr(obj.__dlpack__(copy=False))
    assert 'dltensor' in repr(obj.__dlpack__(copy=None))
    with pytest.raises(BufferError):
        obj.__dlpack__(copy=True)
    with pytest.raises(BufferError):
        obj.__dlpack__(max_version=(1, 0), copy=True)

    # malformed max_version values are rejected
    with pytest.raises(TypeError) as excinfo:
        obj.__dlpack__(max_version=("1", "0"))  # not an integer
    assert 'max_version must be None or tuple[int, int]' in str(excinfo.value)

    # dl_device matching the array's own device is fine, others are rejected
    assert 'dltensor' in repr(obj.__dlpack__(dl_device=None))
    assert 'dltensor' in repr(obj.__dlpack__(dl_device=(1, 0)))
    with pytest.raises(BufferError):
        obj.__dlpack__(dl_device=(99, 0))

    # stream is accepted and ignored
    assert 'dltensor' in repr(obj.__dlpack__(stream=None))
    assert 'dltensor' in repr(obj.__dlpack__(stream=0))
    assert 'dltensor' in repr(obj.__dlpack__(stream=1))

    # Keyword names passed via f(**d) need not be interned/identical to the
    # internal references; equal-but-distinct strings must behave identically.
    with pytest.raises(BufferError):
        obj.__dlpack__(**{''.join(['co', 'py']): True})
    with pytest.raises(BufferError):
        obj.__dlpack__(**{''.join(['dl_', 'device']): (99, 0)})
    assert 'dltensor' in repr(obj.__dlpack__(**{''.join(['str', 'eam']): "0"}))
    assert 'dltensor' in repr(obj.__dlpack__(**{''.join(['co', 'py']): False}))

    # Unrecognized keyword names (e.g., misspellings) are rejected
    with pytest.raises(TypeError):
        obj.__dlpack__(version=1)


def test20b_import_metal_dlpack():
    obj = t.ret_array_api_metal()
    assert obj.__dlpack_device__() == (8, 0)

    class Recorder:
        def __init__(self, wrapped):
            self.wrapped = wrapped
            self.kwargs = None

        def __dlpack_device__(self):
            return self.wrapped.__dlpack_device__()

        def __dlpack__(self, *args, **kwargs):
            assert not args
            self.kwargs = kwargs
            return self.wrapped.__dlpack__(**kwargs)

    rec = Recorder(obj)
    assert t.check_metal_contig(rec) == (8, 0, 2, 2, 4, True, 0)
    # A read-only import uses the cheaper unversioned __dlpack__() (no kwargs).
    assert rec.kwargs == {}

    obj = t.ret_array_api_metal_byte_offset()
    assert t.check_metal_contig(obj) == (8, 0, 2, 2, 3, True, 4)


@needs_torch_mps
def test20c_import_torch_mps_dlpack():
    x = torch.arange(12, device="mps", dtype=torch.float32).reshape(3, 4)
    assert x.__dlpack_device__()[0] == 8
    assert t.inspect_metal_contig(x) == (8, 0, 2, 3, 4, True, True, 0)


@needs_numpy
def test21_return_array_scalar():
    collect()
    dc = t.destruct_count()
    x = t.ret_array_scalar()
    assert np.array_equal(x, np.array(1))
    del x
    collect()
    assert t.destruct_count() - dc == 1


# See PR #162
@needs_torch
def test22_single_and_empty_dimension_pytorch():
    a = torch.ones((1,100,1025), dtype=torch.float32)
    t.noop_3d_c_contig(a)
    a = torch.ones((100,1,1025), dtype=torch.float32)
    t.noop_3d_c_contig(a)
    a = torch.ones((0,100,1025), dtype=torch.float32)
    t.noop_3d_c_contig(a)
    a = torch.ones((100,0,1025), dtype=torch.float32)
    t.noop_3d_c_contig(a)
    a = torch.ones((100,1025,0), dtype=torch.float32)
    t.noop_3d_c_contig(a)
    a = torch.ones((100,0,0), dtype=torch.float32)
    t.noop_3d_c_contig(a)
    a = torch.ones((0,0,0), dtype=torch.float32)
    t.noop_3d_c_contig(a)


# See PR #162
@needs_numpy
def test23_single_and_empty_dimension_numpy():
    a = np.ones((1,100,1025), dtype=np.float32)
    t.noop_3d_c_contig(a)
    a = np.ones((100,1,1025), dtype=np.float32)
    t.noop_3d_c_contig(a)
    a = np.ones((0,100,1025), dtype=np.float32)
    t.noop_3d_c_contig(a)
    a = np.ones((100,0,1025), dtype=np.float32)
    t.noop_3d_c_contig(a)
    a = np.ones((100,1025,0), dtype=np.float32)
    t.noop_3d_c_contig(a)
    a = np.ones((100,0,0), dtype=np.float32)
    t.noop_3d_c_contig(a)
    a = np.ones((0,0,0), dtype=np.float32)
    t.noop_3d_c_contig(a)


# See PR #162
@needs_torch
def test24_single_and_empty_dimension_fortran_order_pytorch():
    # This idiom creates a pytorch 2D tensor in column major (aka, 'F') ordering
    a = torch.ones((0,100), dtype=torch.float32).t().contiguous().t()
    t.noop_2d_f_contig(a)
    a = torch.ones((100,0), dtype=torch.float32).t().contiguous().t()
    t.noop_2d_f_contig(a)
    a = torch.ones((1,100), dtype=torch.float32).t().contiguous().t()
    t.noop_2d_f_contig(a)
    a = torch.ones((100,1), dtype=torch.float32).t().contiguous().t()
    t.noop_2d_f_contig(a)


@needs_numpy
def test25_ro_array():
    a = np.array([1, 2], dtype=np.float32)
    assert t.accept_ro(a) == 1
    assert t.accept_rw(a) == 1
    a.setflags(write=False)
    assert t.accept_ro(a) == 1
    with pytest.raises(TypeError) as excinfo:
        t.accept_rw(a)
    assert 'incompatible function arguments' in str(excinfo.value)


@needs_numpy
def test26_return_ro():
    x = t.ret_numpy_const_ref()
    y = t.ret_numpy_const_ref_f()
    assert t.ret_numpy_const_ref.__doc__  == 'ret_numpy_const_ref() -> numpy.ndarray[dtype=float32, shape=(2, 4), order=\'C\', writable=False]'
    assert t.ret_numpy_const_ref_f.__doc__  == 'ret_numpy_const_ref_f() -> numpy.ndarray[dtype=float32, shape=(2, 4), order=\'F\', writable=False]'
    assert x.shape == (2, 4)
    assert y.shape == (2, 4)
    assert not x.flags.writeable
    assert not y.flags.writeable
    assert np.all(x == [[1, 2, 3, 4], [5, 6, 7, 8]])
    assert np.all(y == [[1, 3, 5, 7], [2, 4, 6, 8]])
    with pytest.raises(ValueError) as excinfo:
        x[0,0] =1
    assert 'read-only' in str(excinfo.value)
    with pytest.raises(ValueError) as excinfo:
        y[0,0] =1
    assert 'read-only' in str(excinfo.value)


def test27_python_array():
    import array
    a = array.array('d', [0, 0, 0, 3.14159, 0])
    assert t.check(a)
    assert t.check_rw_by_value(a)
    assert a[1] == 1.414214
    assert t.check_rw_by_value_float64(a)
    assert a[2] == 2.718282
    assert a[4] == 16.0
    assert t.check_ro_by_value_ro(a)
    assert t.check_ro_by_value_const_float64(a)

    a[1] = 0.1
    a[2] = 0.2
    a[4] = 0.4
    mv = memoryview(a)
    assert t.check(mv)
    assert t.check_rw_by_value(mv)
    assert a[1] == 1.414214
    assert t.check_rw_by_value_float64(mv)
    assert a[2] == 2.718282
    assert a[4] == 16.0
    assert t.check_ro_by_value_ro(mv)
    assert t.check_ro_by_value_const_float64(mv)

    x = t.passthrough(a)
    assert x is a


def test27c_python_complex_array():
    import array
    try:
        a = array.array('Zf', [1.0+2.0j, 3.0+4.0j])
    except:
        pytest.skip('your python does not support complex arrays')
    assert t.check(a)
    t.pass_complex64(a)
    mv = memoryview(a)
    assert t.check(mv)
    t.pass_complex64(mv)
    x = t.passthrough(a)
    assert x is a


def test28_check_bytearray():
    a = bytearray(b'xyz')
    assert t.check(a)
    mv = memoryview(a)
    assert t.check(mv)


@needs_numpy
def test29_check_numpy():
    assert t.check(np.zeros(1))


@needs_torch
def test30_check_torch():
    assert t.check(torch.zeros((1)))


@needs_numpy
def test31_rv_policy():
    def p(a):
        return a.__array_interface__['data']

    x1 = t.ret_numpy_const_ref()
    x2 = t.ret_numpy_const_ref()
    y1 = t.ret_numpy_const()
    y2 = t.ret_numpy_const()

    z1 = t.passthrough(y1)
    z2 = t.passthrough(y2)
    q1 = t.passthrough_copy(y1)
    q2 = t.passthrough_copy(y2)

    assert p(x1) == p(x2)
    assert p(y1) != p(y2)

    assert z1 is y1
    assert z2 is y2
    assert q1 is not y1
    assert q2 is not y2
    assert p(q1) != p(y1)
    assert p(q2) != p(y2)


@needs_numpy
def test32_reference_internal():
    collect()
    dc = t.destruct_count()
    c = t.Cls()

    v1_a = c.f1()
    v1_b = c.f1()
    v2_a = c.f2()
    v2_b = c.f2()
    del c

    assert np.all(v1_a == np.arange(10, dtype=np.float32))
    assert np.all(v1_b == np.arange(10, dtype=np.float32))

    v1_a += 1
    v1_b += 2

    assert np.all(v1_a == np.arange(10, dtype=np.float32) + 1)
    assert np.all(v1_b == np.arange(10, dtype=np.float32) + 2)
    del v1_a
    del v1_b

    assert np.all(v2_a == np.arange(10, dtype=np.float32))
    assert np.all(v2_b == np.arange(10, dtype=np.float32))

    v2_a += 1
    v2_b += 2

    assert np.all(v2_a == np.arange(10, dtype=np.float32) + 3)
    assert np.all(v2_b == np.arange(10, dtype=np.float32) + 3)

    del v2_a
    collect()
    assert t.destruct_count() == dc

    del v2_b
    collect()
    dc += 1
    assert t.destruct_count() == dc

    for i in range(2):
        c2 = t.Cls()

        if i == 0:
            v3_a = c2.f1_ri()
            v3_b = c2.f1_ri()
        else:
            v3_a = c2.f2_ri()
            v3_b = c2.f2_ri()
        del c2

        assert np.all(v3_a == np.arange(10, dtype=np.float32))
        assert np.all(v3_b == np.arange(10, dtype=np.float32))

        v3_a += 1
        v3_b += 2

        assert np.all(v3_a == np.arange(10, dtype=np.float32) + 3)
        assert np.all(v3_b == np.arange(10, dtype=np.float32) + 3)
        del v3_a

        collect()
        assert t.destruct_count() == dc

        del v3_b
        collect()
        dc += 1
        assert t.destruct_count() == dc

    c3 = t.Cls()
    c3_t = (c3,)
    with pytest.raises(RuntimeError) as excinfo:
        c3.f3_ri(c3_t)

    msg = 'nanobind::detail::ndarray_export(): reference_internal policy cannot be applied (ndarray already has an owner)'
    assert msg in str(excinfo.value)


@needs_numpy
def test33_force_contig_numpy():
    a = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    b = t.make_contig(a)
    assert b is a
    a = a.T
    b = t.make_contig(a)
    assert b is not a
    assert np.all(b == a)


@needs_torch
@pytest.mark.filterwarnings
def test34_force_contig_pytorch():
    a = torch.tensor([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    b = t.make_contig(a)
    assert b is a
    a = a.T
    b = t.make_contig(a)
    assert b is not a
    assert torch.all(b == a)


@needs_numpy
def test35_view():
    # 1
    x1 = np.array([[1,2],[3,4]], dtype=np.float32)
    x2 = np.array([[1,2],[3,4]], dtype=np.float64)
    assert np.allclose(x1, x2)
    t.fill_view_1(x1)
    assert np.allclose(x1, x2*2)
    t.fill_view_1(x2)
    assert np.allclose(x1, x2*2)

    # 2
    x1 = np.zeros((3, 4), dtype=np.float32, order='C')
    x2 = np.zeros((3, 4), dtype=np.float32, order='F')
    t.fill_view_2(x1)
    t.fill_view_2(x2)
    x3 = np.zeros((3, 4), dtype=np.float32, order='C')
    t.fill_view_3(x3)
    x4 = np.zeros((3, 4), dtype=np.float32, order='F')
    t.fill_view_4(x4)

    assert np.all(x1 == x2) and np.all(x2 == x3) and np.all(x3 == x4)

    # 3
    x1 = np.array([[1+2j, 3+4j], [5+6j, 7+8j]], dtype=np.complex64)
    x2 = x1 * 2
    t.fill_view_1(x1.view(np.float32))
    assert np.allclose(x1, x2)
    x2 = x1 * (-1+2j)
    t.fill_view_5(x1)
    assert np.allclose(x1, x2)
    x2 = -x2
    t.fill_view_6(x1)
    assert np.allclose(x1, x2)


@needs_numpy
def test36_half():
    if not hasattr(t, 'ret_numpy_half'):
        pytest.skip('half precision test is missing')
    x = t.ret_numpy_half()
    assert x.dtype == np.float16
    assert x.shape == (2, 4)
    assert np.all(x == [[1, 2, 3, 4], [5, 6, 7, 8]])


@needs_numpy
def test37_cast():
    a = t.cast(False)
    b = t.cast(True)
    assert a.ndim == 0 and b.ndim == 0
    assert a.dtype == np.int32 and b.dtype == np.float32
    assert a == 1 and b == 1


@needs_numpy
def test38_complex_decompose():
    x1 = np.array([1 + 2j, 3 + 4j, 5 + 6j], dtype=np.complex64)

    assert np.all(x1.real == np.array([1, 3, 5], dtype=np.float32))
    assert np.all(x1.imag == np.array([2, 4, 6], dtype=np.float32))


@needs_numpy
@pytest.mark.parametrize("variant", [1, 2])
def test_uint32_complex_do_not_convert(variant):
    if variant == 1:
        arg = 1
    else:
        arg = np.uint32(1)
    data = np.array([1.0 + 2.0j, 3.0 + 4.0j])
    t.set_item(data, arg)
    data2 = np.array([123, 3.0 + 4.0j])
    assert np.all(data == data2)


@needs_numpy
def test40_check_generic():
    class DLPackWrapper:
        def __init__(self, o):
            self.o = o
        def __dlpack__(self):
            return self.o.__dlpack__()

    arr = DLPackWrapper(np.zeros((1)))
    assert t.check(arr)


@needs_numpy
def test41_noninteger_stride():
    a = np.array([[1, 2, 3, 4, 0, 0], [5, 6, 7, 8, 0, 0]], dtype=np.float32)
    s = a[:, 0:4]  # slice
    t.pass_float32(s)
    assert t.get_stride(s, 0) == 6
    assert t.get_stride(s, 1) == 1
    try:
        v = s.view(np.complex64)
    except:
        pytest.skip('your version of numpy is too old')
    t.pass_complex64(v)
    assert t.get_stride(v, 0) == 3
    assert t.get_stride(v, 1) == 1

    a = np.array([[1, 2, 3, 4, 0], [5, 6, 7, 8, 0]], dtype=np.float32)
    s = a[:, 0:4]  # slice
    t.pass_float32(s)
    assert t.get_stride(s, 0) == 5
    assert t.get_stride(s, 1) == 1
    v = s.view(np.complex64)
    with pytest.raises(TypeError) as excinfo:
        t.pass_complex64(v)
    assert 'incompatible function arguments' in str(excinfo.value)
    with pytest.raises(TypeError) as excinfo:
        t.get_stride(v, 0)
    assert 'incompatible function arguments' in str(excinfo.value)


@needs_numpy
def test42_const_qualifiers_numpy():
    a = np.array([0, 0, 0, 3.14159, 0], dtype=np.float64)
    assert t.check_rw_by_value(a)
    assert a[1] == 1.414214
    assert t.check_rw_by_value_float64(a)
    assert a[2] == 2.718282
    assert a[4] == 16.0
    assert t.check_ro_by_value_ro(a)
    assert t.check_ro_by_value_const_float64(a)
    a.setflags(write=False)
    assert t.check_ro_by_value_ro(a)
    assert t.check_ro_by_value_const_float64(a)
    assert a[0] == 0.0
    assert a[3] == 3.14159

    a = np.array([0, 0, 0, 3.14159, 0], dtype=np.float64)
    assert t.check_rw_by_const_ref(a)
    assert a[1] == 1.414214
    assert t.check_rw_by_const_ref_float64(a)
    assert a[2] == 2.718282
    assert a[4] == 16.0
    assert t.check_ro_by_const_ref_ro(a)
    assert t.check_ro_by_const_ref_const_float64(a)
    a.setflags(write=False)
    assert t.check_ro_by_const_ref_ro(a)
    assert t.check_ro_by_const_ref_const_float64(a)
    assert a[0] == 0.0
    assert a[3] == 3.14159

    a = np.array([0, 0, 0, 3.14159, 0], dtype=np.float64)
    assert t.check_rw_by_rvalue_ref(a)
    assert a[1] == 1.414214
    assert t.check_rw_by_rvalue_ref_float64(a)
    assert a[2] == 2.718282
    assert a[4] == 16.0
    assert t.check_ro_by_rvalue_ref_ro(a)
    assert t.check_ro_by_rvalue_ref_const_float64(a)
    a.setflags(write=False)
    assert t.check_ro_by_rvalue_ref_ro(a)
    assert t.check_ro_by_rvalue_ref_const_float64(a)
    assert a[0] == 0.0
    assert a[3] == 3.14159


@needs_torch
def test43_const_qualifiers_pytorch():
    a = torch.tensor([0, 0, 0, 3.14159, 0], dtype=torch.float64)
    assert t.check_rw_by_value(a)
    assert a[1] == 1.414214
    assert t.check_rw_by_value_float64(a)
    assert a[2] == 2.718282
    assert a[4] == 16.0
    assert t.check_ro_by_value_ro(a)
    assert t.check_ro_by_value_const_float64(a)
    assert a[0] == 0.0
    assert a[3] == 3.14159

    a = torch.tensor([0, 0, 0, 3.14159, 0], dtype=torch.float64)
    assert t.check_rw_by_const_ref(a)
    assert a[1] == 1.414214
    assert t.check_rw_by_const_ref_float64(a)
    assert a[2] == 2.718282
    assert a[4] == 16.0
    assert t.check_ro_by_const_ref_ro(a)
    assert t.check_ro_by_const_ref_const_float64(a)
    assert a[0] == 0.0
    assert a[3] == 3.14159

    a = torch.tensor([0, 0, 0, 3.14159, 0], dtype=torch.float64)
    assert t.check_rw_by_rvalue_ref(a)
    assert a[1] == 1.414214
    assert t.check_rw_by_rvalue_ref_float64(a)
    assert a[2] == 2.718282
    assert a[4] == 16.0
    assert t.check_ro_by_rvalue_ref_ro(a)
    assert t.check_ro_by_rvalue_ref_const_float64(a)
    assert a[0] == 0.0
    assert a[3] == 3.14159


@needs_cupy
@pytest.mark.filterwarnings
def test44_constrain_order_cupy():
    try:
        c = cp.zeros((3, 5))
        c.__dlpack__()
    except:
        pytest.skip('cupy is missing')

    f = cp.asarray(c, order="F")
    assert t.check_order(c) == 'C'
    assert t.check_order(f) == 'F'
    assert t.check_order(c[:, 2:5]) == '?'
    assert t.check_order(f[1:3, :]) == '?'
    assert t.check_device(cp.zeros((3, 5))) == 'cuda'


@needs_cupy
def test45_implicit_conversion_cupy():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            c = cp.zeros((3, 5))
        except:
            pytest.skip('cupy is missing')

    t.implicit(cp.zeros((2, 2), dtype=cp.int32))
    t.implicit(cp.zeros((2, 2, 10), dtype=cp.float32)[:, :, 4])
    t.implicit(cp.zeros((2, 2, 10), dtype=cp.int32)[:, :, 4])
    t.implicit(cp.zeros((2, 2, 10), dtype=cp.bool_)[:, :, 4])

    with pytest.raises(TypeError) as excinfo:
        t.noimplicit(cp.zeros((2, 2), dtype=cp.int32))

    with pytest.raises(TypeError) as excinfo:
        t.noimplicit(cp.zeros((2, 2), dtype=cp.uint8))


@needs_numpy
def test46_implicit_conversion_contiguous_complex():
    # Test fix for issue #709
    c_f32 = np.random.rand(10, 10)
    c_c64 = c_f32.astype(np.complex64)

    assert c_f32.flags['C_CONTIGUOUS']
    assert c_c64.flags['C_CONTIGUOUS']

    def test_conv(x):
        y = t.test_implicit_conversion(x)
        assert np.all(x == y)
        assert y.flags['C_CONTIGUOUS']

    test_conv(c_f32)
    test_conv(c_c64)

    nc_f32 = c_f32.T
    nc_c64 = c_c64.T

    assert not nc_f32.flags['C_CONTIGUOUS']
    assert not nc_c64.flags['C_CONTIGUOUS']

    test_conv(nc_f32)
    test_conv(nc_c64)


@needs_numpy
def test47_ret_infer():
    assert np.all(t.ret_infer_c() == [[1, 2, 3, 4], [5, 6, 7, 8]])
    assert np.all(t.ret_infer_f() == [[1, 3, 5, 7], [2, 4, 6, 8]])


@needs_numpy
def test48_test_matrix4f():
    a = t.Matrix4f()
    ad = a.data()
    bd = a.data()
    for i in range(16):
        ad[i%4, i//4] = i
    del a, ad
    for i in range(16):
        assert bd[i%4, i//4] == i


@needs_numpy
def test49_test_matrix4f_ref():
    assert t.Matrix4f.data_ref.__doc__.replace('data_ref', 'data') == t.Matrix4f.data.__doc__

    a = t.Matrix4f()
    ad = a.data_ref()
    bd = a.data_ref()
    for i in range(16):
        ad[i%4, i//4] = i
    del a, ad
    for i in range(16):
        assert bd[i%4, i//4] == i


@needs_numpy
def test50_test_matrix4f_copy():
    assert t.Matrix4f.data_ref.__doc__.replace('data_ref', 'data') == t.Matrix4f.data.__doc__

    a = t.Matrix4f()
    ad = a.data_ref()
    for i in range(16):
        ad[i%4, i//4] = i
    bd = a.data_copy()
    for i in range(16):
        ad[i%4, i//4] = 0
    del a, ad
    for i in range(16):
        assert bd[i%4, i//4] == i


@needs_numpy
def test51_return_from_stack():
    assert np.all(t.ret_from_stack_1() == [1,2,3])
    assert np.all(t.ret_from_stack_2() == [1,2,3])


@needs_numpy
def test52_accept_np_both_true_contig():
    a = np.zeros((2, 1), dtype=np.float32)
    assert a.flags['C_CONTIGUOUS'] and a.flags['F_CONTIGUOUS']
    t.accept_np_both_true_contig_a(a)
    t.accept_np_both_true_contig_c(a)
    t.accept_np_both_true_contig_f(a)


@needs_numpy
def test53_issue_930():
    wrapper = t.Wrapper(np.ones(3, dtype=np.float32))
    assert wrapper.value[0] == 1


@needs_numpy
def test54_docs_example():
    ma = t.MyArray()
    aa = ma.array_api()
    assert 'versioned' not in repr(aa.__dlpack__())
    assert 'versioned' not in repr(ma.__dlpack__())
    assert 'versioned' in repr(aa.__dlpack__(max_version=(1, 2)))
    assert 'versioned' in repr(ma.__dlpack__(max_version=(1, 2)))
    assert aa.__dlpack_device__() == (1, 0)
    assert ma.__dlpack_device__() == (1, 0)

    if hasattr(np, 'from_dlpack'):
        x = np.from_dlpack(aa)
        y = np.from_dlpack(ma)
        assert np.all(x == [0.0, 1.0, 2.0, 3.0, 4.0])
        assert np.all(y == [0.0, 1.0, 2.0, 3.0, 4.0])
        ma.mutate()
        assert np.all(x == [0.5, 1.5, 2.5, 3.5, 4.5])
        assert np.all(y == [0.5, 1.5, 2.5, 3.5, 4.5])
    else:
        pytest.skip('your version of numpy is too old')


@needs_numpy
def test55_empty_ndarray():
    arr = t.ret_ndarray_empty()
    assert arr.shape == (0,)
    assert arr.dtype == np.float32
