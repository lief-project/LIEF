<a id="top"></a>
# Catch2 Maintainers

## Current

* Chris Thrasher ([@christhrasher](https://github.com/ChrisThrasher)), gpg key: 56FB686C9DFC8E2C
* Martin Hořeňovský ([@horenmar](https://github.com/horenmar)), gpg key: E29C46F3B8A7502860793B7DECC9C20E314B2360

## Retired

* Phil Nash ([@philsquared](https://github.com/philsquared))
