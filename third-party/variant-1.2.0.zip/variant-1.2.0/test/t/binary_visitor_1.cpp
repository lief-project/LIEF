
#include <mapbox/variant.hpp>

#define NAME_EXT " i-d"
using variant_type = mapbox::util::variant<int, double>;

#include "binary_visitor_impl.hpp"
